import React, { useState } from 'react';
import SectionTitle from './SectionTitle.jsx';
import EditableTable from './EditableTable.jsx';
import useNutritionData from '../hooks/useNutritionData.js';
import { findFoodByName, getGrupoColor, getGrupoLabel, getUnidadFromLabel, getMealTotalKcal } from '../utils/nutritionHelpers.js';
import { foodDatabase } from '../data/foodDatabase.js';
import { useAppContext } from '../context/AppContext.jsx';

const TIEMPO_OPTIONS = ['DESAYUNO', 'COMIDA', 'CENA', 'SNACK', 'PRE', 'POST', 'AYUNAS', 'ANTES DORMIR'];
const DAY_ORDER = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
const DAY_LABELS = { monday: 'LUNES', tuesday: 'MARTES', wednesday: 'MIÉRCOLES', thursday: 'JUEVES', friday: 'VIERNES', saturday: 'SÁBADO', sunday: 'DOMINGO' };

const getMealLocation = (meals, flatIdx) => {
  const list = Array.isArray(meals) ? meals : [];
  if (flatIdx < 0 || flatIdx >= list.length) return null;
  return { dayKey: list[flatIdx].dayKey, localIdx: flatIdx };
};

export default function NutritionSection({ printable = false }) {
  const { data, setters, showToast } = useAppContext();
  const { meals, nutrition = {} } = data;
  const { updateMeal, updateMenuName, addMeal, removeMeal, addMenu, removeMenu, addAlimento, removeAlimento, updateMenu, updateAlimentoDeep, autofillAlimento, onPorcionCantidadChange, recalculateAlimento, reorderAlimento, updateMenuType, addFood, removeFood, updateFood, reorderFood } = useNutritionData(data, setters, showToast);

  const [editingMenuId, setEditingMenuId] = useState(null);
  const [selectedDayForAdd, setSelectedDayForAdd] = useState('monday');

  const mealsList = Array.isArray(meals) ? meals : [];

  const updateNutrition = (key, value) => {
    if (setters.setNutrition) {
      setters.setNutrition(prev => ({ ...prev, [key]: value }));
    }
  };

  const nutritionPlanFields = [
    { key: 'estrategia', label: 'Estrategia', placeholder: 'Ej: Menú fijo + Armar plato' },
    { key: 'kcal', label: 'Kcal', placeholder: 'Ej: 1850', type: 'number' },
    { key: 'prot', label: 'Proteína (g)', placeholder: 'Ej: 165', type: 'number' },
    { key: 'carbs', label: 'Carbos (g)', placeholder: 'Ej: 180', type: 'number' },
    { key: 'grasas', label: 'Grasas (g)', placeholder: 'Ej: 55', type: 'number' },
  ];

  const columns = [
    {
      key: 'gramos',
      label: 'GRAMOS',
      width: '8%',
      minWidth: '50px',
      render: (value, row, onChange, uid, idx) => {
        const handleChange = (e) => {
          onChange('gramos', e.target.value);
        };
        const handleBlur = (e) => {
          const raw = e.target.value.replace(/[^\d.]/g, '');
          if (!raw) return;
          const parts = uid.split('-');
          const mealIdx = parseInt(parts[1], 10);
          const menuIdx = parseInt(parts[2], 10);
          const alimIdx = parseInt(parts[3], 10);
          recalculateAlimento(mealIdx, menuIdx, alimIdx, raw);
        };
        return (
          <input
            type="text"
            inputMode="decimal"
            value={value || ''}
            onChange={handleChange}
            onBlur={handleBlur}
            placeholder="100 g"
            className="premium-table-input"
            style={{ fontSize: '10px' }}
          />
        );
      },
    },
    {
      key: 'porcion',
      label: 'CANT',
      width: '10%',
      minWidth: '60px',
      render: (value, row, onChange, uid, idx) => {
        const handleChange = (e) => {
          const newCantidad = e.target.value;
          onChange('cantidad', newCantidad);
          const parts = uid.split('-');
          const mealIdx = parseInt(parts[1], 10);
          const menuIdx = parseInt(parts[2], 10);
          const alimIdx = parseInt(parts[3], 10);
          onPorcionCantidadChange(mealIdx, menuIdx, alimIdx, newCantidad);
        };
        const food = findFoodByName(row.nombre);
        const base = food?.porciones?.find((p) => p.label === row.porcionBase) || food?.porciones?.[0];
        const unidad = base ? getUnidadFromLabel(base.label) : '';
        return (
          <div className="flex items-center gap-1">
            <input
              type="number"
              min="1"
              value={row.cantidad || ''}
              onChange={handleChange}
              placeholder="1"
              className="premium-table-input"
              style={{ fontSize: '10px' }}
            />
            {unidad && <span className="typo-muted-sm whitespace-nowrap" style={{ fontSize: '10px' }}>{unidad}</span>}
          </div>
        );
      },
    },
    {
      key: 'nombre',
      label: 'ALIMENTO',
      render: (value, row, onChange, uid, idx) => {
        const handleChange = (e) => {
          const newNombre = e.target.value;
          const food = findFoodByName(newNombre);
          if (food) {
            const parts = uid.split('-');
            const mealIdx = parseInt(parts[1], 10);
            const menuIdx = parseInt(parts[2], 10);
            const alimIdx = parseInt(parts[3], 10);
            autofillAlimento(mealIdx, menuIdx, alimIdx, food);
          } else {
            onChange('nombre', newNombre);
          }
        };
        const food = findFoodByName(value);
        const grupo = food?.grupo || null;
        const grupoColor = getGrupoColor(grupo);
        const grupoLabel = getGrupoLabel(grupo);
        const equivalentes = food ? foodDatabase.filter((f) => f.grupo === grupo && f.nombre !== value).map((f) => f.nombre) : [];
        return (
          <div className="input-badge-group">
            <input
              list="food-datalist"
              value={value || ''}
              onChange={handleChange}
              placeholder="Alimento"
              className="premium-table-input"
              style={{ flex: 1 }}
            />
            {grupo && (
              <span
                title={equivalentes.length > 0 ? `Equivalentes: ${equivalentes.join(', ')}` : grupoLabel}
                className={"food-group-badge" + (equivalentes.length > 0 ? " food-group-badge--help" : "")}
                style={{ backgroundColor: grupoColor }}
              >
                {grupoLabel}
              </span>
            )}
          </div>
        );
      },
    },
    {
      key: 'p',
      label: 'P',
      width: '5%',
      minWidth: '35px',
      align: 'center',
      render: (value, row, onChange) => (
        <input
          value={value || ''}
          onChange={(e) => onChange('p', e.target.value)}
          placeholder="0"
          className="premium-table-input text-center"
          style={{ fontSize: '10px' }}
        />
      ),
    },
    {
      key: 'c',
      label: 'C',
      width: '5%',
      minWidth: '35px',
      align: 'center',
      render: (value, row, onChange) => (
        <input
          value={value || ''}
          onChange={(e) => onChange('c', e.target.value)}
          placeholder="0"
          className="premium-table-input text-center"
          style={{ fontSize: '10px' }}
        />
      ),
    },
    {
      key: 'g',
      label: 'G',
      width: '5%',
      minWidth: '35px',
      align: 'center',
      render: (value, row, onChange) => (
        <input
          value={value || ''}
          onChange={(e) => onChange('g', e.target.value)}
          placeholder="0"
          className="premium-table-input text-center"
          style={{ fontSize: '10px' }}
        />
      ),
    },
    {
      key: 'kcal',
      label: 'KCAL',
      width: '6%',
      minWidth: '45px',
      align: 'center',
      render: (value, row, onChange) => (
        <input
          value={value || ''}
          onChange={(e) => onChange('kcal', e.target.value)}
          placeholder="0"
          className="premium-table-input text-center"
          style={{ fontSize: '10px' }}
        />
      ),
    },
  ];

  return (
    <div className={printable ? "space-y-3" : "space-y-4"}>
      <div>
        <div className="premium-page-title">TRATAMIENTO NUTRICIONAL</div>
        {!printable && <div className="premium-subtitle">Plan de comidas, alimentos y seguimiento nutricional.</div>}
      </div>

       {!printable && (
         <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
           <div className="bg-[#2E9E70] text-white rounded-2xl text-center px-4 py-4">
             <p className="typo-card-label-white">Estrategia</p>
             <input
               type="text"
               value={nutrition.estrategia || ''}
               onChange={(e) => updateNutrition('estrategia', e.target.value)}
               placeholder="Mantenimiento"
               className="mt-1 w-full bg-transparent outline-none text-white placeholder-white/60 text-sm font-bold"
             />
           </div>
           <div className="nutrition-metric-card text-center">
             <span className="nutrition-metric-card__label">KCAL</span>
             <input
               type="number"
               value={nutrition.kcal || ''}
               onChange={(e) => updateNutrition('kcal', e.target.value ? Number(e.target.value) : '')}
               placeholder="2200"
               className="nutrition-metric-card__value nutrition-metric-card__value--kcal mt-1 w-full bg-transparent outline-none text-center"
             />
             <p className="typo-muted-sm opacity-60 mt-1">Meta Diaria</p>
           </div>
           <div className="nutrition-metric-card text-center">
             <span className="nutrition-metric-card__label">Proteína (g)</span>
             <input
               type="number"
               value={nutrition.prot || ''}
               onChange={(e) => updateNutrition('prot', e.target.value ? Number(e.target.value) : '')}
               placeholder="140"
               className="nutrition-metric-card__value mt-1 w-full bg-transparent outline-none text-center"
               style={{color: '#0066CC'}}
             />
             <p className="typo-muted-sm opacity-60 mt-1">28%</p>
           </div>
           <div className="nutrition-metric-card text-center">
             <span className="nutrition-metric-card__label">Carbohidratos (g)</span>
             <input
               type="number"
               value={nutrition.carbs || ''}
               onChange={(e) => updateNutrition('carbs', e.target.value ? Number(e.target.value) : '')}
               placeholder="220"
               className="nutrition-metric-card__value mt-1 w-full bg-transparent outline-none text-center"
               style={{color: '#2E9E70'}}
             />
             <p className="typo-muted-sm opacity-60 mt-1">45%</p>
           </div>
           <div className="nutrition-metric-card text-center">
             <span className="nutrition-metric-card__label">Grasas (g)</span>
             <input
               type="number"
               value={nutrition.grasas || ''}
               onChange={(e) => updateNutrition('grasas', e.target.value ? Number(e.target.value) : '')}
               placeholder="55"
               className="nutrition-metric-card__value mt-1 w-full bg-transparent outline-none text-center"
               style={{color: '#CC6600'}}
             />
             <p className="typo-muted-sm opacity-60 mt-1">27%</p>
           </div>
         </div>
       )}

      <datalist id="food-datalist">
        {foodDatabase.map((food, idx) => (
          <option key={idx} value={food.nombre} />
        ))}
      </datalist>

      <div>
        <div className={printable ? "flex items-center mb-3" : "flex justify-between items-center mb-4"}>
          {!printable && (
            <button onClick={() => addMeal(selectedDayForAdd)} className="premium-btn-pill premium-btn-pill--primary print-hide">
              + Comida
            </button>
          )}
        </div>

       {mealsList.map((meal, mIdx) => (
             <div key={meal.id || mIdx} className={printable ? "meal-section" : "meal-section"}>
               <div className="flex flex-wrap gap-3 items-center mb-3">
                <div className="flex gap-2 items-center flex-1 min-w-0">
                  {!printable && (
                  <input
                    type="time"
                    value={meal.hora}
                    onChange={(e) => updateMeal(mIdx, 'hora', e.target.value)}
                    className="premium-meal-pill"
                    style={{ fontSize: '9px', fontWeight: 800, textTransform: 'uppercase', color: '#fff', background: '#16A34A', border: 'none', borderRadius: 999, padding: '3px 8px', letterSpacing: '0.05em', colorScheme: 'dark', WebkitTextFillColor: '#fff' }}
                  />
                  )}
                  {printable && (
                    <span style={{ fontSize: '9px', fontWeight: 800, textTransform: 'uppercase', color: '#fff', background: '#16A34A', borderRadius: 999, padding: '3px 8px', letterSpacing: '0.05em' }}>
                      {meal.hora || meal.tiempo || ''}
                    </span>
                  )}
                   {!printable && (
                   <select
                     value={meal.tiempo}
                     onChange={(e) => updateMeal(mIdx, 'tiempo', e.target.value)}
                     className="premium-meal-select"
                     style={{ fontSize: '12px', fontWeight: 700, color: '#0D2640', background: 'transparent', border: 'none' }}
                   >
                     {TIEMPO_OPTIONS.map((t) => (
                       <option key={t} value={t} style={{ color: '#000' }}>{t}</option>
                     ))}
                   </select>
                   )}
                   {!printable && (
                   <select
                     value={meal.menuType || 'fijo'}
                     onChange={(e) => updateMenuType(mIdx, e.target.value)}
                     className="premium-meal-select"
                     style={{ fontSize: '10px', fontWeight: 700, color: '#6B7280', background: 'transparent', border: 'none', marginLeft: '8px' }}
                   >
                     <option value="fijo" style={{ color: '#000' }}>Menú fijo</option>
                     <option value="armar" style={{ color: '#000' }}>Armar menú</option>
                   </select>
                   )}
                   {printable && <span style={{ fontSize: '12px', fontWeight: 700, color: '#0D2640' }}>{meal.tiempo}</span>}
                   <span style={{ fontSize: '10px', color: '#6B7280', fontWeight: 700, marginLeft: 'auto' }}>{getMealTotalKcal(meal)} kcal</span>
                   {!printable && meal.menuType && (
                     <span style={{ fontSize: '9px', fontWeight: 800, padding: '2px 8px', borderRadius: 999, background: meal.menuType === 'armar' ? '#0B63CE' : '#16A34A', color: '#fff', whiteSpace: 'nowrap' }}>
                       {meal.menuType === 'armar' ? 'ARMAR MENÚ' : 'MENÚ FIJO'}
                     </span>
                   )}
                 </div>
               </div>

              {(meal.menuType === 'armar' ? (meal.foods || []).length === 0 : (meal.menus || []).length === 0) && (
                <div className="text-center py-4 typo-muted-sm">
                  {meal.menuType === 'armar' ? 'Sin alimentos' : 'Sin menús'}
                </div>
              )}

              {(meal.menuType || 'fijo') === 'fijo' ? (
                <EditableTable
                  columns={columns}
                  rows={(meal.menus || []).flatMap((menu, menuIdx) =>
                    (menu.alimentos || []).map((alimento, alimIdx) => ({
                      ...alimento,
                      menuId: menu.id || menuIdx,
                      _menuIdx: menuIdx,
                      _alimIdx: alimIdx,
                    }))
                  )}
                  getRowId={(row) => 'alim-' + mIdx + '-' + row._menuIdx + '-' + row._alimIdx}
                  groupBy="menuId"
                   groupConfig={(meal.menus || []).reduce((acc, menu, idx) => {
                      const letter = String.fromCharCode(65 + idx);
                      acc[menu.id || idx] = { 
                        label: menu.nombre || 'Menú ' + letter, 
                        blockLetter: letter,
                        blockSerie: 'Menú',
                        className: 'menu-group-header' 
                      };
                      return acc;
                    }, {})}
                   onGroupLabelChange={(menuId, nombre) => updateMenuName(mIdx, menuId, nombre)}
                  onUpdateRow={(uid, field, value) => {
                    const parts = uid.split('-');
                    const mealIdx = parseInt(parts[1], 10);
                    const menuIdx = parseInt(parts[2], 10);
                    const alimIdx = parseInt(parts[3], 10);
                    updateAlimentoDeep(mealIdx, menuIdx, alimIdx, (a) => ({ ...a, [field]: value }));
                  }}
                  onRemoveRow={(uid) => {
                    const parts = uid.split('-');
                    const menuIdx = parseInt(parts[2], 10);
                    const alimIdx = parseInt(parts[3], 10);
                    removeAlimento(mIdx, menuIdx, alimIdx);
                  }}
                  onReorder={reorderAlimento}
                  emptyText="Sin alimentos"
                  dragBetweenGroups={false}
                  groupAddRow={(meal.menus || []).reduce((acc, menu, idx) => {
                    acc[menu.id || idx] = () => addAlimento(mIdx, idx);
                    return acc;
                  }, {})}
                  groupRemoveRow={(meal.menus || []).reduce((acc, menu, idx) => {
                    acc[menu.id || idx] = () => removeMenu(mIdx, idx);
                    return acc;
                  }, {})}
                   headerStyle={{ background: '#FFFFFF', fontSize: '9px', fontWeight: 800, letterSpacing: '0.1em', textTransform: 'uppercase' }}
                   headerClassName="nutrition-editor-header"
                 />
              ) : (
                <EditableTable
                  columns={columns}
                  rows={(meal.foods || []).map((food, foodIdx) => ({
                    ...food,
                    _foodIdx: foodIdx,
                  }))}
                  getRowId={(row) => 'food-' + mIdx + '-' + row._foodIdx}
                  groupBy={null}
                  groupConfig={null}
                  onUpdateRow={(uid, field, value) => {
                    const parts = uid.split('-');
                    const mealIdx = parseInt(parts[1], 10);
                    const foodIdx = parseInt(parts[2], 10);
                    updateFood(mealIdx, foodIdx, (f) => ({ ...f, [field]: value }));
                  }}
                  onRemoveRow={(uid) => {
                    const parts = uid.split('-');
                    const foodIdx = parseInt(parts[2], 10);
                    removeFood(mIdx, foodIdx);
                  }}
                  onReorder={reorderFood}
                  emptyText="Sin alimentos"
                  dragBetweenGroups={false}
                   headerStyle={{ background: '#FFFFFF', fontSize: '9px', fontWeight: 800, letterSpacing: '0.1em', textTransform: 'uppercase' }}
                   headerClassName="nutrition-editor-header"
                />
              )}

              {!printable && (meal.menuType || 'fijo') === 'fijo' && (meal.menus || []).some(menu => (menu.alimentos || []).length === 0) && (
                <div className="mt-2">
                  <button onClick={() => { const menuIdx = 0; addAlimento(mIdx, menuIdx); }} className="premium-btn-pill premium-btn-pill--primary print-hide">
                    + Alimento
                  </button>
                </div>
              )}

              {!printable && (meal.menuType || 'fijo') === 'armar' && (meal.foods || []).length === 0 && (
                <div className="mt-2">
                  <button onClick={() => addFood(mIdx)} className="premium-btn-pill premium-btn-pill--primary print-hide">
                    + Alimento
                  </button>
                </div>
              )}

             {!printable && (
               <button onClick={() => addMenu(mIdx)} className="premium-btn-pill premium-btn-pill--ghost print-hide">
                + Menú
               </button>
             )}
           </div>
         ))}
      </div>
    </div>
  );
}
