import { guideSections, glossaryTerms } from '../data/guideContent.js';
import { getDayType } from '../utils/dayType.js';

export const generateDashboardFitnessHTML = (data, mode = 'todo') => {
  const person = data.person || {};
  const firstName = person.firstName || (person.nombre || '').trim().split(/\s+/)[0] || '';
  const lastName = person.lastName || (person.nombre || '').trim().split(/\s+/).slice(1).join(' ') || '';
  const nombre = person.nombre || `${firstName} ${lastName}`.trim() || 'Paciente';
  const routines = data.routines || {};
  const upper = data.warmupUpper || [];
  const lower = data.warmupLower || [];
  const calendar = data.calendar || [];
  const meals = data.meals || [];
  const supplements = data.supplements || [];
  const stats = data.stats || {};
  const avances = data.avances || {};
  const estadisticas = data.estadisticas || {};
  const tNutri = data.tratamientoNutricional || {};
  const tEntre = data.tratamientoEntrenamiento || {};
  const clinico = data.clinico || {};
  const diasStat = tEntre.dias ? tEntre.dias.split(',').filter(d => d.trim()).length : '';
  const cardioStat = tEntre.cardio ? (tEntre.cardio.match(/\d+/) || [])[0] : '';

  const groupExercisesBySequence = (exercises) => {
    if (!exercises.length) return [];

    const sorted = [...exercises].sort((a, b) => {
      const seqA = (a.secuencia || a.codigo || '').trim();
      const seqB = (b.secuencia || b.codigo || '').trim();
      const matchA = seqA.match(/^([A-Za-z])(\d+)$/);
      const matchB = seqB.match(/^([A-Za-z])(\d+)$/);

      if (!matchA && !matchB) return 0;
      if (!matchA) return -1;
      if (!matchB) return 1;

      const letterA = matchA[1].toUpperCase();
      const letterB = matchB[1].toUpperCase();
      const numA = parseInt(matchA[2], 10);
      const numB = parseInt(matchB[2], 10);

      if (letterA !== letterB) return letterA.localeCompare(letterB);
      return numA - numB;
    });

    const groups = new Map();
    sorted.forEach(ex => {
      const seq = (ex.secuencia || ex.codigo || '').trim();
      const match = seq.match(/^([A-Za-z])/);
      const letter = match ? match[1].toUpperCase() : 'Z';

      if (!groups.has(letter)) {
        groups.set(letter, []);
      }
      groups.get(letter).push(ex);
    });

    return Array.from(groups.entries()).map(([letter, exs]) => {
      const count = exs.length;
      let tipo = 'SERIE SIMPLE';
      if (count === 2) tipo = 'BISERIE';
      else if (count === 3) tipo = 'TRISERIE';
      else if (count >= 4) tipo = 'SERIE GIGANTE / CIRCUITO';

      return {
        letra: letter,
        tipo,
        ejercicios: exs,
        indicacion: exs[0]?.indicacion || '',
      };
    });
  };

  const bloqueColor = () => '#0D2640';

  const today = new Date().toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' });

  const logoHTML = `<img src="data:image/svg+xml;base64,PHN2ZyB2aWV3Qm94PSIwIDAgMTg2LjM5MyA1Mi4xNjE0IiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8ZyBpZD0iR3JvdXAgMyI+CjxwYXRoIGlkPSJWZWN0b3IiIGQ9Ik0xNTguNTUyIDQyLjQ2MjNDMTYzLjcyNCAzNy4xNTY5IDE2Ny44OTMgMzEuMjM4OCAxNzAuODM0IDI0Ljc0MjlDMTcxLjk4IDIyLjIxNzIgMTcyLjg0OCAxOS43MDY1IDE3Mi44OTcgMTYuOTkxNUMxNzIuOTI5IDE1LjIxODEgMTcyLjMyNCAxMy4yMzA1IDE3MC42MzggMTIuMjc0QzE2My43NjMgOC4zNTM1IDE1MS43MDQgNi42NDk4IDE0My42MzQgNS45MDI1N0MxMzUuMTI3IDUuMTE1NDggMTI2Ljc0NiA1LjAxNTg1IDExOC4xNDIgNS4wMjA4M0wxMjQuMzU3IDMuNTc2MTdDMTQ0LjY1NCAtMC43MDc5NzggMTY1Ljc3NiAtMS44Mjg4MyAxODUuODQ1IDQuMDY0MzdDMTg2Ljc3OCA0LjMzODM1IDE4Ni4yNzYgNS40NzQxNSAxODYuMTAxIDYuMDYxOThDMTgyLjA2MyAxOS40NTI0IDE3NC45MjEgMzIuMzc0NiAxNjMuNjcgNDEuOTQ0MkMxNTguODY4IDQ2LjA5MzkgMTUzLjUxNiA0OS42MzU4IDE0Ny4zNDQgNTIuMTYxNEMxNTEuMjk1IDQ5LjAyOCAxNTUuMDcxIDQ2LjAzNDEgMTU4LjU1NyA0Mi40NjIzSDE1OC41NTJaIiBmaWxsPSIjMDA2NkNDIi8+CjxwYXRoIGlkPSJWZWN0b3JfMiIgZD0iTTExMi4wODUgMzQuOTg1MkgxMDUuNzA3TDEwMy41OTUgMjEuOTg4M0wxMDAuMTUyIDM0Ljk4NTJIOTUuMjc0MkwxMDAuNzA5IDEzLjEzNkgxMDcuMDQ5TDEwOS4yNDggMjYuMTgyOEwxMTIuNjI2IDEzLjEzNkgxMTcuNTQyTDExMi4wODUgMzQuOTg1MloiIGZpbGw9IiMwMDY2Q0MiLz4KPHBhdGggaWQ9IlZlY3Rvcl8zIiBkPSJNMTguMjYyNiAxNC43OTQ5QzIxLjQxMDkgMTcuNTI5OCAxOC4zMTE3IDI2Ljc3MDYgMTYuODYwMyAyOS44NTkyQzE1LjQ0MTYgMzIuODgzIDEyLjU5MzQgMzQuOTQ1NCA4Ljk5NzYgMzQuOTg1MkgwTDUuNDQwMDMgMTMuMTM2SDEzLjQ5MzdDMTUuMzEwNyAxMy4xNTEgMTYuOTU4NSAxMy42OTQgMTguMjY4IDE0Ljc5NDlIMTguMjYyNlpNMTIuMDU4NiAyOC4xNTA1QzEzLjA3OSAyNS4zNTA5IDEzLjcwMSAyMi41NzYxIDE0LjE0ODQgMTkuNzE2N0MxNC4yNzM5IDE4LjkxNDcgMTQuMDMzOSAxNy44ODM1IDEzLjI5MTggMTcuNDg1QzEyLjI3MTQgMTYuOTM3IDExLjAwNTYgMTYuOTcxOSA5Ljg0ODggMTcuMTY2MUw2LjQ2NTgzIDMwLjk0NTJDOS4yNjQ5NyAzMS4xODQzIDExLjAzMjggMzAuOTY1MSAxMi4wNTg2IDI4LjE1MDVaIiBmaWxsPSIjMDA2NkNDIi8+CjxwYXRoIGlkPSJWZWN0b3JfNCIgZD0iTTMyLjE1NDYgMzMuOTgzNkMzMC4wMzIgMzUuMzgzNCAyNy41OTMgMzUuNDczMSAyNS4xNDMxIDM1LjM1ODVDMjEuODQ3NCAzNS4yMDQxIDE5Ljc3OTUgMzMuMDU3IDE5Ljk3NTkgMjkuOTYzNEMyMC4yMTYgMjYuMTYyNSAyMS4xMzgxIDIyLjMzNjcgMjIuNTM0OSAxOC42OTUxQzI0LjQwMSAxMy44MjgxIDI5LjI0MDkgMTEuOTY1IDM0LjQ1MTcgMTMuMDc1OUMzNi44NDE2IDEzLjU4NCAzOC40MTMxIDE1LjM0MjUgMzguMzU4NSAxNy43MTg3QzM4LjI3NjcgMjEuMzgwMiAzNy4yNTYzIDI1LjAzMTcgMzYuMDc3NyAyOC41ODM1QzM1LjM2MjkgMzAuNzMwNiAzNC4xODQ0IDMyLjY0ODUgMzIuMTYgMzMuOTgzNkgzMi4xNTQ2Wk0yNy45Njk1IDMxLjUzMjZDMjkuMjEzNiAzMS4yMjg4IDMwLjAzNzUgMzAuMjQyNCAzMC40MTQgMjkuMTM2NUMzMS41NzA3IDI1Ljc0OSAzMi4zNjc0IDIyLjMzMTcgMzIuOTIzOSAxOC44MTQ3QzMzLjAzMzEgMTguMTE3MyAzMi43MzI5IDE3LjIyNTYgMzIuMTQzNyAxNi44NzE5QzMxLjM1MjUgMTYuMzk4NiAzMC4zNTQgMTYuNTE4MiAyOS40OTE4IDE2LjkxNjdDMjguOTA4IDE3LjE4NTcgMjguMjgwNSAxNy45NzI4IDI3Ljk5MTMgMTguNzU0OUMyNi43MTQ1IDIyLjIyMjEgMjUuOTEyNCAyNS44Mjg3IDI1LjMzOTUgMjkuNDcwM0MyNS4yNDEzIDMwLjA5NzkgMjUuNjIzMyAzMC45MDUgMjYuMDMyNSAzMS4yMTM4QzI2LjUwMTcgMzEuNTY3NSAyNy4yNjAyIDMxLjcwMiAyNy45NzUgMzEuNTI3N0wyNy45Njk1IDMxLjUzMjZaIiBmaWxsPSIjMDA2NkNDIi8+CjxwYXRoIGlkPSJWZWN0b3JfNSIgZD0iTTE0NS45MSAyOS4yNzEyQzE0NS4yNjYgMzEuODIxNyAxNDMuNjU2IDMzLjg0OTIgMTQwLjkyMiAzNC43NjA5QzEzOC41NDMgMzUuNTQ4IDEzNS44MDQgMzUuNjU3NSAxMzMuNDE0IDM0LjkwMDNDMTI5Ljc0OCAzMy43Mzk2IDEzMC4wMjYgMzAuNTM2NSAxMzAuODcyIDI3LjY1NzFMMTM2LjA3MiAyNy42NzIxQzEzNS45NzkgMjguNzQzMSAxMzUuMzY4IDMwLjA1ODMgMTM2LjIwMyAzMC45NEMxMzcuMjk5IDMyLjEwMDcgMTM5LjQ3NiAzMS40MTgyIDE0MC4yMDggMzAuMjUyNUMxNDEuMDkyIDI4Ljg0NzcgMTQwLjU5NSAyNy40MzMgMTM5LjA4NCAyNi41MzEzTDEzNS40NDQgMjQuMzU5M0MxMzMuNjk4IDIzLjMxODIgMTMyLjkwMSAyMS42Mzk0IDEzMy4wNTQgMTkuNzc2M0MxMzMuMjc4IDE3LjA2NjMgMTM0LjkxNSAxNC43NTk5IDEzNy42NTkgMTMuNjI0MUMxMzkuNzYgMTIuNzU3MyAxNDIuMTU2IDEyLjU2OCAxNDQuNDA0IDEzLjAyMTNDMTQ2LjU0OCAxMy40NTQ3IDE0OC4wODEgMTQuOTA5MyAxNDguMjEyIDE2LjkxNjlDMTQ4LjI3MiAxNy44MjM1IDE0OC4xMTQgMTguNzI1MiAxNDcuODkgMTkuNjY2N0gxNDIuNDU2QzE0Mi42NTcgMTguNzk5OSAxNDMuMDk0IDE3Ljg3ODMgMTQyLjQ5OSAxNy4xMzExQzE0MS45MjYgMTYuNDA4OCAxNDAuNjcxIDE2LjUwMzQgMTM5LjgyNiAxNi44OTJDMTM5LjAyOSAxNy4yNTU2IDEzOC42MDMgMTguMDU3NyAxMzguNTY1IDE4Ljk2NDNDMTM4LjUyNyAyMC4wMDA1IDEzOS4wMTMgMjAuNzU3NyAxMzkuOTk1IDIxLjI5NTdDMTQzLjUzNiAyMy4yNDg1IDE0Ny4wMjggMjQuODQyNiAxNDUuOTEgMjkuMjc2MlYyOS4yNzEyWiIgZmlsbD0iIzAwNjZDQyIvPgo8cGF0aCBpZD0iVmVjdG9yXzYiIGQ9Ik0xNTcuNDQ1IDM0Ljc0MDVDMTU1LjEwOSAzNS41Mzc1IDE1Mi41MTcgMzUuNjIyMiAxNTAuMTg4IDM0Ljk5OTVDMTQ2LjM3OSAzMy45ODMzIDE0Ni40MTIgMzAuNjQwNiAxNDcuMzM5IDI3LjY0NjdIMTUyLjU0NUMxNTIuMzE2IDI4Ljc0NzYgMTUxLjgxNCAzMC44OTQ3IDE1My4yMDUgMzEuMzM4MUMxNTQuNDk4IDMxLjc1MTUgMTU1LjkxMSAzMS4zODc5IDE1Ni41ODggMzAuMzkxNkMxNTkuNTEzIDI2LjA4MjUgMTUwLjg5MSAyNS44Mzg0IDE0OS43NzMgMjEuNzM4NkMxNDguNzAzIDE3LjgzMyAxNTEuNDc1IDE0LjAyNzEgMTU1LjcyIDEzLjExNTVDMTU3LjY4NSAxMi42OTIgMTU5LjYzMyAxMi42MDczIDE2MS41MzcgMTMuMjA1MUMxNjQuNzM0IDE0LjIwNjQgMTY1LjE1NCAxNi45NTYzIDE2NC40MTIgMTkuNjcxMkwxNTguOTI5IDE5LjY0NjNDMTU5LjE1MiAxOC43NzQ1IDE1OS42NzEgMTcuNTk4OSAxNTguODUyIDE2Ljk5MTFDMTU3LjY3OSAxNi4xMjQzIDE1NS45IDE2LjcyMjEgMTU1LjI4OSAxNy44NDhDMTU0LjY3MyAxOC45OTM3IDE1NC45MDIgMjAuMzY4NiAxNTYuMTk1IDIxLjEzMDhMMTYwLjA5MSAyMy40MjczQzE2Mi40ODYgMjQuODQyMSAxNjMuMTAzIDI3LjI1MzIgMTYyLjMyOCAyOS42NzQyQzE2MS41ODYgMzEuOTgwNyAxNjAuMDg1IDMzLjgzMzggMTU3LjQ1IDM0LjczNTVMMTU3LjQ0NSAzNC43NDA1WiIgZmlsbD0iIzAwNjZDQyIvPgo8cGF0aCBpZD0iVmVjdG9yXzciIGQ9Ik00NC41Nzg3IDMxLjE0OTRDNDUuOTU5MiAzMi4xODA1IDQ3Ljc5MjYgMzEuMzk4NCA0OC40OTEgMzAuMTEzMkM0OS4wOTY2IDI5LjAwMjMgNDkuMzMxMyAyNy45MjEzIDQ5LjU4MjMgMjYuNjUxSDU1LjAyMjNDNTQuMTA1NiAzMS4xMTk1IDUxLjU5NTcgMzUuMTY0NSA0Ni4wNDEgMzUuMzYzOEM0NC43MjA2IDM1LjQxMzYgNDMuNDM4MyAzNS4zOTg2IDQyLjE3NzkgMzUuMDk0OEMzNy4zOTgxIDMzLjk0NCAzOC40Njc2IDI4LjczMzMgMzkuMjI2IDI1LjMzMDlDMzkuNzcxNiAyMi44NzUgNDAuMzYwOSAyMC41MTg3IDQxLjM1OTUgMTguMjIyMkM0Mi44NzA5IDE0Ljc0MDEgNDYuMjgxMSAxMi42NTc4IDUwLjM5NTMgMTIuNzY3NEM1MS43NzU3IDEyLjgwMjIgNTMuMDkwNyAxMi45MTE4IDU0LjM1MTEgMTMuNTA5NkM1Ny4zMDMxIDE0LjkxOTQgNTYuOTEwMiAxOC4yMDcyIDU2LjI4MjcgMjAuNzc3N0w1MC44NyAyMC44Mzc1TDUxLjMyMjggMTguNDAxNUM1MS40MTU2IDE3LjkwMzQgNTEuMTQyOCAxNy4yMTA5IDUwLjc5MzYgMTYuOTIyQzUwLjM1MTYgMTYuNTUzNCA0OS42MzY4IDE2LjQ3MzcgNDguOTY1NyAxNi41NzMzQzQ3LjcxNjIgMTYuNzYyNiA0Ni45Njg2IDE3Ljc5ODggNDYuNTQ4NSAxOC45Mzk1QzQ1LjMzNzIgMjIuMjUyMyA0NC42Mzg4IDI1LjY1OTcgNDQuMDQ0IDI5LjE0MThDNDMuOTQwMyAyOS43Mzk2IDQ0LjA0NCAzMC43MzU5IDQ0LjU4NDIgMzEuMTM5NEw0NC41Nzg3IDMxLjE0OTRaIiBmaWxsPSIjMDA2NkNDIi8+CjxwYXRoIGlkPSJWZWN0b3JfOCIgZD0iTTEyOS4xOCAyNS43MDQ2SDEyMi41MzRMMTIxLjIyNSAzMS4wMDQ5TDEyOC42NDYgMzEuMDA5OUwxMjcuNTcxIDM0Ljk4NTJIMTE0Ljg0MUwxMjAuMjg2IDEzLjEzNkgxMzIuOTRMMTMxLjkzIDE3LjIzNTlMMTI0LjY0MSAxNy4yMTFMMTIzLjQ5NSAyMS44Nzg3SDEzMC4xOUwxMjkuMTggMjUuNzA0NloiIGZpbGw9IiMwMDY2Q0MiLz4KPHBhdGggaWQ9IlZlY3Rvcl85IiBkPSJNNzEuNjk3MiAyMS44Nzg3TDcwLjc0MjQgMjUuNzA0Nkg2My4xNTI1TDYwLjg1NTQgMzQuOTg1Mkg1NS40MjYzTDYwLjg2NjMgMTMuMTM2SDc0LjM2TDczLjMzOTYgMTcuMjE2SDY1LjI0MjNMNjQuMDk2NSAyMS44Nzg3SDcxLjY5NzJaIiBmaWxsPSIjMDA2NkNDIi8+CjxwYXRoIGlkPSJWZWN0b3JfMTAiIGQ9Ik04OC42MTczIDM0Ljk4NTJIODMuMTU1NEw4Ny42MTMzIDE3LjIxNkg4Mi45MTU0TDgzLjkzNTcgMTMuMTM2SDk4LjYyOThMOTcuNjE0OSAxNy4yMTZIOTIuOTg3OUw4OC42MTczIDM0Ljk4NTJaIiBmaWxsPSIjMDA2NkNDIi8+CjxwYXRoIGlkPSJWZWN0b3JfMTEiIGQ9Ik03Ni40MjIzIDM0Ljk4NTJINzAuOTk4Nkw3Ni40Mzg3IDEzLjEzNkg4MS44NTY5TDc2LjQyMjMgMzQuOTg1MloiIGZpbGw9IiMwMDY2Q0MiLz4KPC9nPgo8L3N2Zz4K" style="height:28px;width:auto;display:block">`;

  const parseDate = (value) => {
    if (!value) return null;
    const str = String(value).trim();
    if (!str) return null;
    const iso = str.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (iso) {
      const d = new Date(str + 'T00:00:00');
      return Number.isNaN(d.getTime()) ? null : d;
    }
    const dmy = str.match(/^(\d{2})\/(\d{2})\/(\d{2,4})$/);
    if (dmy) {
      let [, dd, mm, yyyy] = dmy;
      if (yyyy.length === 2) yyyy = '20' + yyyy;
      const d = new Date(`${yyyy}-${mm}-${dd}T00:00:00`);
      return Number.isNaN(d.getTime()) ? null : d;
    }
    const d = new Date(str);
    return Number.isNaN(d.getTime()) ? null : d;
  };

  const fechaConsulta = parseDate(data.fechaConsulta);
  const consultaLabel = fechaConsulta ? fechaConsulta.toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' }) : '';
  const prox = fechaConsulta ? new Date(fechaConsulta) : new Date();
  prox.setMonth(prox.getMonth() + 1);
  const proxima = prox.toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' });

  const esc = (str) => String(str ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');


  const dayRoutine = routines.monday || { tipo: 'rest', actividad: '', fases: [] };
  const dayMeals = meals || [];
  const daySupps = supplements || [];

  const warmupList = (title, w, type) => {
    const all = [...(w || [])];
    if (!all.length) return '';

    const faseColor = (fase) => {
      if (fase === 'GENERAL' || fase === 'CG') return '#0D2640';
      if (fase === 'MOVILIDAD' || fase === 'ED') return '#2E9E70';
      if (fase === 'ESPECÍFICO' || fase === 'CE') return '#0B63CE';
      return '#0D2640';
    };

    const exercises = all.flatMap(fase => (fase.bloques || []).flatMap(bloque => (bloque.ejercicios || []).map((ej, idx) => ({
      ...ej,
      fase: fase.nombre || fase.fase || '',
      idx: idx + 1,
    }))));

    return `
      <div class="section-card">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
          <div style="width:32px;height:32px;border-radius:999px;background:#2E9E70;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:12px">
            ${type === 'lower' ? 'L' : 'U'}
          </div>
          <div>
            <div style="font-size:12px;font-weight:700;color:#0D2640">${esc(title)}</div>
            <div style="font-size:10px;color:#6B7280">${exercises.length} ejercicios</div>
          </div>
        </div>
        <div style="padding-top:8px">
          ${exercises.map((ej, i) => {
            const isLastEj = i === exercises.length - 1;
            return `
              <div style="display:flex;gap:10px;padding:8px 0;border-bottom:${!isLastEj ? '1px solid #F3F4F6' : 'none'}">
                <div style="width:22px;height:22px;border-radius:999px;background:${faseColor(ej.fase)};color:#fff;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:800;flex-shrink:0">${i + 1}</div>
                <div style="flex:1">
                  <div style="font-size:11px;font-weight:700;color:#0D2640">${esc(ej.nombre || '')}</div>
                  <div style="font-size:10px;color:#6B7280;margin-top:1px">${esc(ej.prescripcion || ej.codigo || '')}</div>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
  };

  const routineCard = () => {
    const ejercicios = (dayRoutine.fases || []).flatMap(fase => (fase.bloques || []).flatMap(bloque => (bloque.ejercicios || []).map((ex, i) => ({
      ...ex,
      tipo: fase.nombre || '',
      indicacion: bloque.indicacion || '',
      tipoBloque: bloque.tipo || '',
    }))));

    return `
      <div class="training-card">
        <div class="training-header">
          <span class="training-label">Entrenamiento</span>
        </div>
        <div class="training-title">${esc(dayRoutine.actividad || dayRoutine.tipo || '')}</div>
        <div class="training-list">
          ${ejercicios.length === 0 ? '<div style="text-align:center;padding:20px;opacity:.6;font-size:12px">Día de descanso o sin ejercicios</div>' : ejercicios.map((ex, i) => `
            <div class="training-item">
              <div style="flex:1;min-width:0">
                <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
                  <span style="width:20px;height:20px;border-radius:999px;background:#2E9E70;color:#fff;display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:800;flex-shrink:0">${i + 1}</span>
                  <span style="font-size:12px;font-weight:700;line-height:1.3">${esc(ex.nombre || '—')}</span>
                  ${ex.badgeTecnica ? `<span class="training-badge">${esc(ex.badgeTecnica)}</span>` : ''}
                </div>
                <div class="training-item-meta">${esc(ex.prescripcion || '')}</div>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  };

  const mealCard = (meal) => {
    const foods = meal.foods || [];
    const menuType = meal.menuType || 'fijo';
    const menuColor = menuType === 'armar' ? '#0B63CE' : '#2E9E70';
    const kcal = meal.kcal || 0;
    const macros = meal.macros || {};
    const p = macros.proteinas || 0;
    const c = macros.carbos || 0;
    const g = macros.grasas || 0;

    return `
      <div class="section-card">
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:10px">
          <span class="supp-pill" style="background:${menuColor}">${esc(meal.hour || meal.tiempo || '')}</span>
          <span style="font-size:12px;font-weight:700;color:#0D2640">${esc(meal.time || 'Comida')}</span>
          <span style="font-size:10px;color:#6B7280;margin-left:auto">${kcal} kcal • ${p}P ${c}C ${g}G</span>
        </div>
        <div style="border-top:1px solid #F3F4F6;padding-top:8px">
          ${foods.map(f => `
            <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #F3F4F6">
              <div style="flex:1;min-width:0">
                <span style="font-size:11px;font-weight:700;color:#0D2640">${esc(f.grams || '')}${f.unit ? esc(f.unit) : 'g'} </span>
                <span style="font-size:11px;color:#4B5563">${esc(f.name || '')}</span>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  };

  const suppCard = () => {
    if (!daySupps.length) return '<div class="section-card" style="text-align:center;padding:20px;color:#6B7280;font-size:11px">Sin suplementos</div>';
    return `
      <div class="section-card">
        <div class="section-title">Suplementación</div>
        ${daySupps.map(s => `
          <div style="display:flex;align-items:center;gap:8px;padding:10px 0;border-bottom:1px solid #F3F4F6">
            <span class="supp-pill">${esc(s.hora || s.horario || '')}</span>
            <div style="flex:1">
              <div style="font-size:11px;font-weight:700;color:#0D2640">${esc(s.nombre || s.suplemento || '')}</div>
              <div style="font-size:10px;color:#6B7280">${esc(s.dosis || '')}</div>
            </div>
          </div>
        `).join('')}
      </div>
    `;
  };

  const avancesCard = () => {
    const pesoActual = avances.peso?.actual;
    const pesoAnterior = avances.peso?.anterior;
    const pesoDelta = avances.peso?.delta;

    const measures = [
      ['Abdomen', avances.abdomen?.actual, avances.abdomen?.anterior, avances.abdomen?.delta],
      ['Grasa kg', avances.grasaKg?.actual, avances.grasaKg?.anterior, avances.grasaKg?.delta],
      ['Grasa %', avances.grasaPct?.actual, avances.grasaPct?.anterior, avances.grasaPct?.delta],
      ['Pliegue', avances.pliegue?.actual, avances.pliegue?.anterior, avances.pliegue?.delta],
    ].filter(([, actual]) => actual);

    if (!pesoActual && !measures.length) return '';

    const roundDelta = (d) => {
      const n = Number(d);
      if (!Number.isFinite(n)) return '0';
      return n.toFixed(1);
    };

    const descansoNum = parseFloat(String(estadisticas.descanso || '0')) || 0;
    const descansoPct = Math.min(Math.round((descansoNum / 8) * 100), 100);

    const miniCards = [
      { title: 'Nutrición', value: String(estadisticas.nutricion || 0), suffix: '%', pct: Number(estadisticas.nutricion || 0) },
      { title: 'Entreno', value: String(estadisticas.entrenamiento || 0), suffix: '%', pct: Number(estadisticas.entrenamiento || 0) },
      { title: 'Cardio', value: String(Math.min(Math.round((Number(estadisticas.cardio || 0) / 3) * 100), 100)), suffix: '%', pct: Math.min(Math.round((Number(estadisticas.cardio || 0) / 3) * 100), 100) },
      { title: 'Descanso', value: String(descansoPct), suffix: '%', pct: descansoPct },
    ];

     return `
       <div style="margin-bottom:16px">
         ${pesoActual ? `
          <div style="background:#0066CC;border-radius:18px;padding:16px;color:#fff;margin-bottom:12px">
            <div style="font-size:9px;font-weight:800;letter-spacing:0.12em;text-transform:uppercase;opacity:.7">${esc(avances.peso?.label || 'PESO')}</div>
            <div style="display:flex;align-items:baseline;gap:8px;margin-top:8px">
              <span style="font-size:14px;font-weight:600;opacity:.5">${pesoAnterior || '—'}</span>
              <span style="font-size:24px;font-weight:900;line-height:1">${pesoActual}</span>
              <span style="font-size:12px;opacity:.6">kg</span>
            </div>
            <div style="font-size:8px;font-weight:700;letter-spacing:0.1em;opacity:.4;margin-top:6px;text-transform:uppercase">Anterior → Actual</div>
            ${pesoDelta ? `<div style="margin-top:10px;display:inline-block;background:rgba(255,255,255,0.15);padding:4px 10px;border-radius:999px;font-size:11px;font-weight:800">↑ +${roundDelta(pesoDelta)}</div>` : ''}
          </div>
        ` : ''}

        ${measures.length > 0 ? `
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">
            ${measures.map(([label, actual, anterior, delta]) => {
              const d = roundDelta(delta || (anterior ? Number(actual) - Number(anterior) : 0));
              const isPositive = Number(d) > 0;
              const arrow = isPositive ? '↑ +' : '↓ ';
              return `
                <div style="background:#fff;border:1px solid #E8E8E8;border-radius:16px;padding:12px;text-align:center;position:relative">
                   <span style="font-size:9px;letter-spacing:1px;color:#6B7280;font-weight:700;display:block">${esc(label)}</span>
                   ${anterior ? `<div style="position:absolute;top:6px;right:6px;font-size:9px;font-weight:800;color:#2E9E70;padding:2px 8px;border-radius:9999px;background:rgba(46,158,112,0.08)">${esc(arrow + d)}</div>` : ''}
                   <div style="display:flex;align-items:baseline;justify-content:center;gap:4px;margin-top:4px">
                     <span style="font-size:12px;font-weight:700;color:#9CA3AF">${anterior || '—'}</span>
                     <span style="font-size:16px;font-weight:900;color:#0D2640">${esc(actual || '—')}</span>
                   </div>
                   <div style="font-size:8px;font-weight:700;letter-spacing:0.1em;opacity:.4;margin-top:2px;text-transform:uppercase">Anterior → Actual</div>
                 </div>
              `;
            }).join('')}
          </div>
        ` : ''}

         <div style="background:#2E9E70;border-radius:16px;padding:14px;color:#fff;margin-bottom:12px">
           <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
             <span style="font-size:10px;font-weight:800;letter-spacing:0.12em;text-transform:uppercase;opacity:.8">Adherencia al plan</span>
             <span style="font-size:20px;font-weight:900;line-height:1">${estadisticas.adherencia || 0}%</span>
           </div>
           <div style="height:8px;background:rgba(255,255,255,0.2);border-radius:999px;overflow:hidden">
             <div style="height:100%;background:#fff;border-radius:999px;width:${estadisticas.adherencia || 0}%"></div>
           </div>
         </div>

         <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px">
           ${miniCards.map(card => `
             <div style="background:#fff;border:1px solid #E8E8E8;border-radius:16px;padding:12px;text-align:center">
               <span style="font-size:9px;letter-spacing:1px;color:#6B7280;font-weight:700;display:block">${esc(card.title)}</span>
               <div style="display:flex;align-items:baseline;justify-content:center;gap:2px;margin-top:4px">
                 <span style="font-size:16px;font-weight:900;color:#0D2640">${card.value}</span>
                 <span style="font-size:11px;font-weight:800;color:#6B7280">${card.suffix}</span>
               </div>
               <div style="height:6px;background:#F3F4F6;border-radius:999px;overflow:hidden;margin-top:8px">
                 <div style="height:100%;background:#2E9E70;border-radius:999px;width:${Math.min(card.pct, 100)}%"></div>
               </div>
             </div>
           `).join('')}
         </div>
       </div>
    `;
  };

  const calentamientoHTML = () => {
    const generalFases = [...upper.filter(f => f.id === 'CG'), ...lower.filter(f => f.id === 'CG')];
    const upperFases = upper.filter(f => f.id !== 'CG');
    const lowerFases = lower.filter(f => f.id !== 'CG');

    const upperDays = calendar.filter(c => (c.actividad || '').includes('Upper')).map(c => c.dia);
    const lowerDays = calendar.filter(c => (c.actividad || '').includes('Lower')).map(c => c.dia);

    const hasGeneral = generalFases.length > 0;
    const hasUpper = upperFases.length > 0;
    const hasLower = lowerFases.length > 0;

    if (!hasGeneral && !hasUpper && !hasLower) return '';

    const faseColor = (id) => {
      if (id === 'CG') return '#0D2640';
      if (id === 'ED') return '#0D2640';
      if (id === 'CE') return '#0D2640';
      return '#0D2640';
    };

    const countEj = (fase) => (fase.bloques || []).flatMap(bloque => (bloque.ejercicios || [])).length;

    const renderFaseContent = (fase, isFirst) => {
      const ejercicios = (fase.bloques || []).flatMap(bloque => (bloque.ejercicios || []));
      if (!ejercicios.length) return '';
      const color = faseColor(fase.id);
      const isGeneral = fase.id === 'CG';
      const headerText = !isGeneral ? (`${esc(fase.nombre || fase.fase || '')}`).toUpperCase() : (isFirst ? 'OPCIONES DE CALENTAMIENTO • ELIGE <span style="display:inline-flex;align-items:center;justify-content:center;font-size:7px;font-weight:800;padding:1px 5px;border-radius:999px;background:#0D2640;color:#fff">1</span>' : '');
      return `
        ${headerText ? `<div style="font-size:9px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:#6B7280;margin-bottom:6px">${headerText}</div>` : ''}
        ${ejercicios.map((ej, i) => {
          const isLastEj = i === ejercicios.length - 1;
          return `
            <div style="display:flex;gap:10px;padding:8px 0;border-bottom:${!isLastEj ? '1px solid #F3F4F6' : 'none'}">
              <div style="width:22px;height:22px;border-radius:999px;background:${color};color:#fff;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:800;flex-shrink:0">${esc(ej.codigo || String(i + 1))}</div>
              <div style="flex:1">
                <div style="font-size:11px;font-weight:700;color:#0D2640">${esc(ej.nombre || '')}</div>
                <div style="font-size:10px;color:#6B7280;margin-top:1px">${esc(ej.prescripcion || '')}</div>
              </div>
            </div>
          `;
        }).join('')}
      `;
    };

    return `
      <div style="margin-bottom:16px">
        ${hasGeneral ? `
          <details style="border:1px solid #E8E8E8;border-radius:12px;margin:0 0 10px 0;background:#fff">
              <summary style="padding:11px 12px;font-weight:700;font-size:13px;cursor:pointer;list-style:none;color:#0D2640;display:flex;align-items:center;justify-content:space-between">
                <div style="display:flex;flex-direction:column;flex:1">
                  <span>General</span>
                  <span style="font-size:8px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:#6B7280">TODOS LOS DÍAS DE ENTRENAMIENTO</span>
                </div>
                <span style="font-size:10px;color:#6B7280;font-weight:700">${generalFases.reduce((sum, f) => sum + countEj(f), 0)} ejercicios opcionales ▼</span>
              </summary>
            <div class="content" style="padding:10px 12px 12px 12px">
              ${generalFases.map((fase, idx) => renderFaseContent(fase, idx === 0)).join('')}
            </div>
          </details>
        ` : ''}

        ${hasUpper ? `
          <details style="border:1px solid #E8E8E8;border-radius:12px;margin:0 0 10px 0;background:#fff">
            <summary style="padding:11px 12px;font-weight:700;font-size:13px;cursor:pointer;list-style:none;color:#0D2640;display:flex;align-items:center;justify-content:space-between">
              <div style="display:flex;flex-direction:column;flex:1">
                <span>Upper Body</span>
                <span style="font-size:8px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:#6B7280">TREN SUPERIOR • ${upperDays.join(', ').toUpperCase() || 'DIAS DE ENTRENO'}</span>
              </div>
              <span style="font-size:10px;color:#6B7280;font-weight:700;margin-left:8px">${upperFases.reduce((sum, f) => sum + countEj(f), 0)} ejercicios ▼</span>
            </summary>
            <div class="content" style="padding:10px 12px 12px 12px">
              ${upperFases.map((fase, idx) => renderFaseContent(fase, idx === 0)).join('')}
            </div>
          </details>
        ` : ''}

        ${hasLower ? `
          <details style="border:1px solid #E8E8E8;border-radius:12px;margin:0 0 10px 0;background:#fff">
            <summary style="padding:11px 12px;font-weight:700;font-size:13px;cursor:pointer;list-style:none;color:#0D2640;display:flex;align-items:center;justify-content:space-between">
              <div style="display:flex;flex-direction:column;flex:1">
                <span>Lower Body</span>
                <span style="font-size:8px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:#6B7280">TREN INFERIOR • ${lowerDays.join(', ').toUpperCase() || 'DIAS DE ENTRENO'}</span>
              </div>
              <span style="font-size:10px;color:#6B7280;font-weight:700;margin-left:8px">${lowerFases.reduce((sum, f) => sum + countEj(f), 0)} ejercicios ▼</span>
            </summary>
            <div class="content" style="padding:10px 12px 12px 12px">
              ${lowerFases.map((fase, idx) => renderFaseContent(fase, idx === 0)).join('')}
            </div>
          </details>
        ` : ''}
      </div>
    `;
  };

  const semanaCard = (dayLabel, dayKey, m, r, s) => {
    const tipo = getDayType(r.actividad);
    const tipoLabel = tipo === 'lower' ? 'Lower' : tipo === 'upper' ? 'Upper' : tipo === 'rest' ? 'Descanso' : 'Full';

    return `
      <div class="section-card">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
          <div style="width:28px;height:28px;border-radius:999px;background:#0D2640;color:#fff;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:800">${dayLabel}</div>
          <div>
            <div style="font-size:12px;font-weight:700;color:#0D2640">${esc(r.actividad || tipoLabel)}</div>
            <div style="font-size:10px;color:#6B7280">${m.length} comidas • ${s.length} suplementos</div>
          </div>
        </div>
        ${m.length > 0 ? `
          <div style="border-top:1px solid #F3F4F6;padding-top:8px;margin-top:8px">
            ${m.map(meal => `
              <div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid #F3F4F6">
              <span style="font-size:9px;font-weight:800;padding:3px 8px;border-radius:999px;background:#2E9E70;color:#fff;white-space:nowrap">${esc(meal.hour || meal.tiempo || '')}</span>
                <span style="font-size:11px;font-weight:700;color:#0D2640">${esc(meal.time || '')}</span>
                <span style="font-size:10px;color:#6B7280;margin-left:auto">${meal.kcal || 0} kcal</span>
              </div>
            `).join('')}
          </div>
        ` : ''}
      </div>
    `;
  };

  const guiaHTML = () => {
    if (!guideSections.length) return '';

    const fmt = (str) => {
      if (!str) return '';
      return String(str).replace(/\n/g, '<br>');
    };

    const badgeColor = (section) => {
      if (section.type === 'faq') return '#6B7280';
      if (section.type === 'split') return '#059669';
      if (section.type === 'grid') return '#059669';
      if (section.type === 'columns') return '#6B7280';
      return '#0D2640';
    };

    const sideBadge = (variant) => {
      if (variant === 'green') return 'background:#ECFDF5;color:#059669;border:1px solid #A7F3D0';
      if (variant === 'red') return 'background:#FEF2F2;color:#DC2626;border:1px solid #FECACA';
      return 'background:#F0F7FF;color:#0B63CE;border:1px solid #BFDBFE';
    };

    const renderSectionInner = (section) => {
      switch (section.type) {
        case 'split':
          return `
            <div style="display:flex;flex-direction:column;gap:12px">
              ${(section.sides || []).map(side => `
                <div>
                  <span style="font-size:9px;font-weight:700;padding:2px 8px;border-radius:999px;display:inline-block;margin-bottom:6px;${sideBadge(side.variant)}">${esc(side.label || '')}</span>
                  <div style="font-size:12px;color:#4B5563;line-height:1.6">${fmt(side.body || '')}</div>
                  ${(side.dont || []).map(d => `
                    <div style="display:flex;align-items:center;gap:4px;margin-top:6px;font-size:12px;color:#DC2626"><span>✕</span> ${esc(d)}</div>
                  `).join('')}
                  ${(side.swaps || []).map(sw => `
                    <div style="display:flex;gap:4px;margin-top:6px;font-size:12px"><span style="font-weight:700;color:#0D2640;min-width:70px">${esc(sw.label || '')}</span><span style="color:#4B5563">${esc(sw.value || '')}</span></div>
                  `).join('')}
                  ${(side.categories || []).map(cat => `
                    <div style="margin-top:8px">
                      <div style="font-size:9px;font-weight:700;color:#6B7280;margin-bottom:4px">${esc(cat.name || '')}</div>
                      ${(cat.items || []).map(item => `
                        <div style="display:flex;align-items:flex-start;gap:4px;font-size:12px;color:#4B5563;line-height:1.6"><span style="color:#0D2640;margin-top:1px">•</span> ${fmt(String(item).replace(/^<b>[^<]*<\/b>\s*/, ''))}</div>
                      `).join('')}
                    </div>
                  `).join('')}
                </div>
              `).join('')}
            </div>
          `;
        case 'columns':
          return `
            <div style="display:flex;flex-direction:column;gap:8px">
              ${(section.columns || []).map(col => `
                <div>
                  <div style="font-size:11px;font-weight:700;color:#0D2640;margin-bottom:4px">${esc(col.title || '')}</div>
                  <div style="font-size:12px;color:#4B5563;line-height:1.6">${fmt(col.body || '')}</div>
                </div>
              `).join('')}
            </div>
          `;
        case 'grid':
          return `
            ${section.note ? `<span style="font-size:8px;font-weight:700;padding:2px 8px;border-radius:999px;background:#DCFCE7;color:#166534;border:1px solid #86EFAC;display:inline-block;margin-bottom:8px">${esc(section.note || '')}</span>` : ''}
            <div style="display:flex;flex-direction:column;gap:10px">
              ${(section.blocks || []).map(block => `
                <div>
                  <div style="font-size:11px;font-weight:700;color:#0D2640;margin-bottom:6px">${esc(block.title || '')}</div>
                  ${block.highlight
                    ? `<div style="background:#0D2640;border-radius:12px;padding:12px"><div style="font-size:11px;color:rgba(255,255,255,0.8);line-height:1.6">${fmt((block.items || []).join('; '))}</div></div>`
                    : `<div style="display:flex;flex-wrap:wrap;gap:4px">
                        ${(block.items || []).map(item => `
                          <span style="font-size:10px;color:#0D2640;background:#F3F4F6;border-radius:8px;padding:3px 6px">${esc(item)}</span>
                        `).join('')}
                      </div>`
                  }
                </div>
              `).join('')}
            </div>
          `;
        case 'faq':
          return `
            <div style="display:flex;flex-direction:column;gap:4px">
              ${(section.items || []).map((f, idx) => `
                <details style="border:1px solid #E8E8E8;border-radius:12px">
                  <summary style="padding:10px 14px;cursor:pointer;list-style:none;font-size:11px;font-weight:700;display:flex;justify-content:space-between;align-items:center;color:#0D2640">
                    <span style="flex:1">${esc(f.q || '')}</span>
                    <span style="font-size:9px;color:#6B7280;flex-shrink:0">▼</span>
                  </summary>
                  <div style="padding:12px 14px;border-top:1px solid #E8E8E8;font-size:12px;color:#4B5563;line-height:1.6">${fmt(f.a || '')}</div>
                </details>
              `).join('')}
            </div>
          `;
        default:
          return `<div style="font-size:12px;color:#4B5563;line-height:1.6">${fmt(section.contenido || section.body || '')}</div>`;
      }
    };

    return `
      <details class="guia-outer">
        <summary>
          <div style="display:flex;align-items:center;gap:10px">
            <div style="display:flex;flex-direction:column">
              <span style="font-size:9px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;opacity:.7">Contenido educativo</span>
              <span style="font-size:15px;font-weight:900">Guía DocFitness</span>
            </div>
          </div>
          <span style="font-size:9px;opacity:.6">Léelo ▼</span>
        </summary>
        <div class="guia-content">
          ${guideSections.map((section, i) => `
            <details class="guia-inner">
              <summary>
                <div style="display:flex;align-items:center;gap:8px;flex:1;min-width:0;padding:8px 12px">
                  <span style="width:16px;height:16px;border-radius:999px;background:${badgeColor(section)};color:#fff;display:flex;align-items:center;justify-content:center;font-size:7px;font-weight:700;flex-shrink:0">${i + 1}</span>
                  <span style="font-size:11px;font-weight:700;color:#0D2640;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(section.title || '')}</span>
                </div>
                <span style="font-size:10px;color:#6B7280;flex-shrink:0;padding:6px 8px">▼</span>
              </summary>
              <div class="guia-inner-content">
                ${renderSectionInner(section)}
              </div>
            </details>
          `).join('')}
        </div>
      </details>
    `;
  };

  const glosarioHTML = () => {
    if (!glossaryTerms.length) return '';

    const fmt = (str) => {
      if (!str) return '';
      return String(str).replace(/\n/g, '<br>');
    };

    const catColor = (cat) => {
      const map = {
        'Intensidad': '#059669',
        'Series': '#6B7280',
        'Notación': '#374151',
        'Nutrición': '#059669',
        'Composición corporal': '#6B7280',
        'Calentamiento': '#92400E',
        'Hábitos': '#92400E',
      };
      return map[cat] || '#0D2640';
    };

    const grouped = {};
    glossaryTerms.forEach(term => {
      const cat = term.cat || 'General';
      if (!grouped[cat]) grouped[cat] = [];
      grouped[cat].push(term);
    });

    const cats = ['Intensidad','Series','Notación','Calentamiento','Nutrición','Composición corporal','Hábitos'].filter(c => grouped[c]);

    return `
      <details class="guia-outer">
        <summary style="background:#F3F4F6;border-radius:12px">
          <div style="display:flex;align-items:center;gap:10px">
            <div style="display:flex;flex-direction:column">
              <span style="font-size:9px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:#6B7280">Términos clave</span>
              <span style="font-size:15px;font-weight:900;color:#0D2640">Glosario DocFitness</span>
            </div>
          </div>
          <span style="font-size:9px;opacity:.6">Léelo ▼</span>
        </summary>
        <div class="guia-content">
            ${cats.map(cat => `
              <div style="margin-bottom:10px">
                <div style="display:flex;align-items:center;gap:5px;margin-bottom:5px">
                  <span style="width:6px;height:6px;border-radius:999px;background:${catColor(cat)}"></span>
                  <span style="font-size:10px;font-weight:700;color:#0D2640">${esc(cat)}</span>
                </div>
                <div style="display:grid;gap:3px">
                  ${grouped[cat].map(term => `
                 <details style="border-bottom:1px solid #E8E8E8">
                     <summary style="padding:5px 8px;cursor:pointer;list-style:none;font-size:10px;font-weight:700;display:flex;justify-content:space-between;align-items:center;color:#0D2640;background:#fff">
                       <div style="display:flex;align-items:center;gap:4px;flex:1;min-width:0">
                         <span style="font-size:6px;font-weight:800;padding:1px 4px;border-radius:999px;background:${catColor(cat)};color:#fff;white-space:nowrap;flex-shrink:0">
                           ${(() => { const m={'Intensidad':'INT','Series':'SER','Notación':'NOT','Calentamiento':'CAL','Nutrición':'NUT','Composición corporal':'COMP','Hábitos':'HAB'}; return m[cat] || cat.substring(0,3).toUpperCase(); })()}
                         </span>
                         <span style="font-size:9px;font-weight:700;color:#0D2640;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex-shrink:1;min-width:0">${esc(term.title || '')}</span>
                         ${term.subtitle ? `<span style="font-size:7px;color:#6B7280;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex-shrink:1;min-width:0">— ${esc(term.subtitle)}</span>` : ''}
                       </div>
                       <span style="font-size:9px;color:#6B7280;flex-shrink:0;padding:5px 6px">▼</span>
                     </summary>
                    <div style="padding:8px 10px;font-size:9px;color:#4B5563;line-height:1.4">
                      <div style="margin-bottom:${term.example ? '6px' : '0'}">${fmt(term.body || '')}</div>
                      ${term.example ? `<div style="display:flex;align-items:flex-start;gap:3px"><span style="color:#0D2640;margin-top:1px">•</span> <span style="font-weight:700">Ej:</span> ${fmt(term.example)}</div>` : ''}
                    </div>
                  </details>
                  `).join('')}
                </div>
              </div>
            `).join('')}
          </div>
        </details>
      `;
  };

  const heroHTML = () => {
    return `
    <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:16px">
      <div style="flex:1;min-width:0">
        <div style="font-size:22px;font-weight:900;line-height:1.1;color:#0D2640">Hola,</div>
        <div style="font-size:22px;font-weight:900;line-height:1.1;color:#0D2640">${esc(firstName)}${lastName ? ' ' + esc(lastName) : ''}</div>
        ${consultaLabel ? `<div style="font-size:12px;font-weight:700;color:#0066CC;margin-top:4px">Consulta: ${consultaLabel}</div>` : ''}
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px">
          <span style="font-size:9px;font-weight:800;padding:4px 10px;border-radius:999px;background:#0066CC;color:#fff;text-transform:uppercase;letter-spacing:0.8px;white-space:nowrap">Actualización: ${proxima}</span>
        </div>
      </div>
    </div>
    `;
  };

  const calendarioHTML = () => {
    const days = [
      { label: 'LUN', key: 'monday' },
      { label: 'MAR', key: 'tuesday' },
      { label: 'MIE', key: 'wednesday' },
      { label: 'JUE', key: 'thursday' },
      { label: 'VIE', key: 'friday' },
      { label: 'SAB', key: 'saturday' },
      { label: 'DOM', key: 'sunday' },
    ];
    const todayKey = ['sunday','monday','tuesday','wednesday','thursday','friday','saturday'][new Date().getDay()];

    const dayDetails = (dayLabel, dayKey) => {
      const r = routines[dayKey] || { actividad: '', fases: [] };
      const tipo = getDayType(r.actividad);
      const tipoLabel = tipo === 'lower' ? 'Lower' : tipo === 'upper' ? 'Upper' : tipo === 'rest' ? 'Descanso' : 'Full';
      const isToday = dayKey === todayKey;

      const ejercicios = (r.fases || [])
        .filter(fase => !['CG', 'ED', 'CE'].includes(fase.id))
        .flatMap(fase => (fase.bloques || []).flatMap(bloque => (bloque.ejercicios || []).map((ex, i) => ({
          ...ex,
          tipo: fase.nombre || '',
          indicacion: bloque.indicacion || '',
        }))));

      const warmupHtml = isToday ? (warmupList('CALENTAMIENTO', [...lower, ...upper], 'both') || '') : '';

      const bloques = groupExercisesBySequence(ejercicios);

      return `
        <details id="dia-${dayKey}" class="day-details" style="border:1px solid #E8E8E8;border-radius:12px;margin:0 0 10px 0;background:#fff">
          <summary style="padding:11px 12px;font-weight:700;font-size:13px;cursor:pointer;list-style:none;color:#fff;background:#0D2640;display:flex;align-items:center;justify-content:space-between">
            <div style="display:flex;align-items:center;gap:8px">
              <span style="font-size:9px;font-weight:800;padding:3px 10px;border-radius:999px;background:#0066CC;color:#fff;white-space:nowrap">${dayLabel}</span>
              <span>${esc(r.actividad || tipoLabel)} ${isToday ? '<span style="font-size:9px;font-weight:800;padding:2px 8px;border-radius:999px;background:#2E9E70;color:#fff;margin-left:6px">HOY</span>' : ''}</span>
            </div>
            <span style="font-size:10px;color:rgba(255,255,255,0.6);font-weight:700">${ejercicios.length} ejercicios ▼</span>
          </summary>
          <div class="content" style="padding:10px 12px 12px 12px">
            ${isToday ? `<div style="font-size:10px;font-weight:800;letter-spacing:0.12em;text-transform:uppercase;color:#6B7280;margin-bottom:8px;padding-left:2px">CALENTAMIENTO</div>` : ''}
            ${warmupHtml}
            ${bloques.length > 0 ? `
              <div style="margin-top:${isToday && warmupHtml ? '8px' : '0'}">
                ${bloques.map((bloque, bIdx) => {
                  const color = bloqueColor(bloque.tipo);
                  const isMulti = /biserie|triserie/i.test(bloque.tipo || '');
                  return `
                    <div style="margin-bottom:${bIdx > 0 ? '8px' : '0'};padding-top:${bIdx > 0 ? '6px' : '0'}">
                      <div style="display:flex;align-items:center;gap:4px;margin-bottom:4px;opacity:.7">
                        <span style="width:14px;height:14px;border-radius:999px;background:${color};color:#fff;display:flex;align-items:center;justify-content:center;font-size:7px;font-weight:700;flex-shrink:0">${esc(bloque.letra)}</span>
                        <span style="font-size:8px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:${color}">${esc(bloque.tipo || 'BLOQUE')}</span>
                      </div>
                      <div style="${isMulti ? 'margin-left:10px;border-left:1px solid #F3F4F6;padding-left:8px' : ''}">
                        ${bloque.ejercicios.map((ex, exIdx) => {
                          const seq = (ex.codigo || ex.secuencia || '').trim();
                          const displayCode = seq || '—';
                          const isLastEj = exIdx === bloque.ejercicios.length - 1;
                          return `
                            <div style="display:flex;align-items:flex-start;gap:6px;padding:4px 0;border-bottom:${!isLastEj ? '1px solid #F3F4F6' : 'none'}">
                              <span style="width:16px;height:16px;border-radius:999px;background:#0D2640;color:#fff;display:flex;align-items:center;justify-content:center;font-size:7px;font-weight:800;flex-shrink:0">${esc(displayCode)}</span>
                              <div style="flex:1;min-width:0">
                                <div style="font-size:10px;font-weight:700;color:#0D2640;line-height:1.3">${esc(ex.nombre || '—')}</div>
                                <div style="font-size:9px;color:#6B7280;margin-top:1px">${esc(ex.prescripcion || '')}</div>
                              </div>
                            </div>
                          `;
                        }).join('')}
                      </div>
                    </div>
                  `;
                }).join('')}
              </div>
            ` : '<div style="text-align:center;padding:16px;opacity:.6;font-size:11px;color:#6B7280">Día de descanso o sin ejercicios</div>'}
          </div>
        </details>
      `;
    };

     return `
       ${days.map(d => dayDetails(d.label, d.key)).join('')}
     `;
  };

  const comidasHTML = () => {
    if (!dayMeals.length) return '<div style="text-align:center;padding:20px;opacity:.6;font-size:11px;color:#6B7280">Sin comidas cargadas</div>';

    const grouped = {};
    dayMeals.forEach(meal => {
      const key = meal.time || meal.tiempo || 'Comida';
      if (!grouped[key]) grouped[key] = [];
      grouped[key].push(meal);
    });

    return Object.entries(grouped).map(([time, meals]) => {
      const totalKcal = meals.reduce((sum, m) => sum + (m.kcal || 0), 0);
      const p = meals.reduce((sum, m) => sum + ((m.macros?.proteinas || 0)), 0);
      const c = meals.reduce((sum, m) => sum + ((m.macros?.carbos || 0)), 0);
      const g = meals.reduce((sum, m) => sum + ((m.macros?.grasas || 0)), 0);

      const meal = meals[0];
      const menuTypeLabel = meal.menuType === 'armar' ? 'Armar menú' : meal.menuType === 'fijo' ? 'Menú fijo' : '';

      const GROUP_ORDER = { 'proteinas': 0, 'carbohidratos': 1, 'grasas': 2 };
      const getFoodGroup = (food) => {
        const m = food.macros;
        if (!m) return null;
        const { proteinas, carbos, grasas } = m;
        if (proteinas > 0 && proteinas >= carbos && proteinas >= grasas) {
          return { key: 'proteinas', label: 'PROT', bg: '#0066CC' };
        }
        if (carbos > 0 && carbos >= proteinas && carbos >= grasas) {
          return { key: 'carbohidratos', label: 'CARB', bg: '#2E9E70' };
        }
        if (grasas > 0 && grasas >= proteinas && grasas >= carbos) {
          return { key: 'grasas', label: 'GRASA', bg: '#CC6600' };
        }
        return null;
      };
      const getFoodGroupBadge = (food) => {
        const g = getFoodGroup(food);
        if (!g) return '';
        return `<span style="font-size:8px;font-weight:800;padding:2px 6px;border-radius:999px;background:${g.bg};color:#fff;white-space:nowrap;margin-right:6px">${g.label}</span>`;
      };

      const renderFoodTable = (foods) => {
        if (!foods.length) return '';
        const hasAnyMacros = foods.some(f => f.macros);
        let sortedFoods = foods;
        if (hasAnyMacros) {
          sortedFoods = [...foods].sort((a, b) => {
            const oa = getFoodGroup(a) ? GROUP_ORDER[getFoodGroup(a).key] : 99;
            const ob = getFoodGroup(b) ? GROUP_ORDER[getFoodGroup(b).key] : 99;
            return oa - ob;
          });
        }
        const thStyle = "font-size:9px;font-weight:800;letter-spacing:0.1em;text-transform:uppercase;color:#6B7280;padding:6px 8px;background:#F8FAFC"
        const tdLeft = "font-size:11px;padding:5px 8px;border-bottom:1px solid #F3F4F6";
        const tdRight = "font-size:11px;padding:5px 8px;border-bottom:1px solid #F3F4F6;text-align:right";
        return `
          <table style="width:100%;border-collapse:collapse">
            <thead>
              <tr>
                <th style="${thStyle}">Cant.</th>
                <th style="${thStyle}">Alimento</th>
                <th style="${thStyle};text-align:right">kcal</th>
              </tr>
            </thead>
            <tbody>
              ${sortedFoods.map((f) => `
                <tr>
                  <td style="${tdLeft}">${esc(f.grams || '')}${f.unit ? esc(f.unit) : 'g'}</td>
                  <td style="${tdLeft}">${getFoodGroupBadge(f)}${esc(f.name || '')}</td>
                  <td style="${tdRight}">${f.kcal || ''}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        `;
      };

      const renderMenu = (menu, menuIdx, totalMenus) => {
        const menuName = menu.nombre || (totalMenus > 1 ? `Opción ${menuIdx + 1}` : '');
        const alimentos = menu.alimentos || [];
        const hasMenuName = menuName.length > 0;

        return `
          ${hasMenuName ? `<div style="font-size:9px;font-weight:800;letter-spacing:0.1em;text-transform:uppercase;color:#0D2640;margin-bottom:4px;margin-top:${menuIdx > 0 ? '10px' : '6px'};padding-top:${menuIdx > 0 ? '8px' : '0'}">${esc(menuName)}</div>` : ''}
          ${renderFoodTable(alimentos)}
        `;
      };

      const renderArmar = () => {
        const foods = meals.flatMap(m => m.foods || []);
        if (!foods.length) return '';
        return `
          <div style="font-size:9px;font-weight:800;letter-spacing:0.1em;text-transform:uppercase;color:#0D2640;margin-bottom:4px;margin-top:6px">OPCIONES DE MACROS • ELIGE <span style="display:inline-flex;align-items:center;justify-content:center;font-size:8px;font-weight:800;padding:2px 6px;border-radius:999px;background:#0D2640;color:#fff">1</span> POR GRUPO</div>
          ${renderFoodTable(foods)}
        `;
      };

      const allMenus = meals.flatMap(m => (m.menus || []));
      const hasMenus = allMenus.length > 0;
      const hasArmar = meal.menuType === 'armar' && meals.flatMap(m => m.foods || []).length > 0;

      return `
        <details class="meal-details" style="border:1px solid #E8E8E8;border-radius:12px;margin:0 0 10px 0;background:#fff">
          <summary style="padding:11px 12px;cursor:pointer;list-style:none;color:#0D2640;display:flex;flex-direction:column;gap:2px">
            <div style="display:flex;align-items:center;justify-content:space-between;width:100%;gap:6px">
              <div style="display:flex;align-items:center;gap:4px;flex:1;min-width:0">
                <span style="font-size:9px;font-weight:800;padding:3px 8px;border-radius:999px;background:#2E9E70;color:#fff;white-space:nowrap">${esc(meal.hour || meal.tiempo || '')}</span>
                ${menuTypeLabel ? `<span style="font-size:9px;font-weight:800;padding:2px 8px;border-radius:999px;background:#0B63CE;color:#fff;white-space:nowrap">${menuTypeLabel}</span>` : ''}
              </div>
              <span style="font-size:10px;color:#6B7280;font-weight:700;white-space:nowrap;flex-shrink:0">${totalKcal} kcal • ${p}P ${c}C ${g}G ▼</span>
            </div>
            <span style="font-size:13px;font-weight:700;color:#0D2640">${esc(time)}</span>
          </summary>
          <div class="content" style="padding:10px 12px 12px 12px">
            ${hasMenus ? allMenus.map((menu, idx) => renderMenu(menu, idx, allMenus.length)).join('') : ''}
            ${hasArmar ? renderArmar() : ''}
          </div>
        </details>
      `;
    }).join('');
  };

  const suplementosHTML = () => {
    if (!daySupps.length) return '<div style="text-align:center;padding:20px;opacity:.6;font-size:11px;color:#6B7280">Sin suplementos</div>';

    const grouped = {};
    daySupps.forEach(s => {
      const key = s.horario || s.hora || 'Sin horario';
      if (!grouped[key]) grouped[key] = [];
      grouped[key].push(s);
    });

    return Object.entries(grouped).map(([horario, sups]) => {
      return `
        <details class="supp-details" style="border:1px solid #E8E8E8;border-radius:12px;margin:0 0 10px 0;background:#fff">
          <summary style="padding:11px 12px;font-weight:700;font-size:13px;cursor:pointer;list-style:none;color:#0D2640;display:flex;align-items:center;justify-content:space-between">
            <div style="display:flex;align-items:center;gap:8px">
              <span style="font-size:9px;font-weight:800;padding:3px 8px;border-radius:999px;background:#2E9E70;color:#fff;white-space:nowrap">${esc(horario)}</span>
              <span>Suplementación</span>
            </div>
            <span style="font-size:10px;color:#6B7280;font-weight:700">${sups.length} items ▼</span>
          </summary>
          <div class="content" style="padding:10px 12px 12px 12px">
              ${sups.map(sup => `
                <div style="display:flex;align-items:flex-start;gap:8px;padding:8px 0;border-bottom:1px solid #F3F4F6">
                  <div style="flex:1">
                    <div style="font-size:11px;font-weight:700;color:#0D2640">${esc(sup.nombre || sup.suplemento || '')}</div>
                    <div style="font-size:10px;color:#6B7280">${esc(sup.dosis || '')}${sup.frecuencia ? ' • ' + esc(sup.frecuencia) : ''}${sup.tomarCon ? ' • Con ' + esc(sup.tomarCon) : ''}</div>
                    ${sup.notas ? `<div style="font-size:10px;color:#6B7280;margin-top:2px;font-style:italic">${esc(sup.notas)}</div>` : ''}
                  </div>
                </div>
             `).join('')}
          </div>
        </details>
      `;
    }).join('');
  };

  const metricCard = (label, value, valueColor = '#0D2640', unit = '') => `
    <div style="background:#fff;border:1px solid #E8E8E8;border-radius:16px;padding:12px;text-align:center;min-width:70px;flex:1">
      <span style="font-size:8px;font-weight:800;letter-spacing:0.12em;text-transform:uppercase;color:#6B7280;display:block;margin-bottom:4px">${esc(label)}</span>
      <span style="font-size:14px;font-weight:800;color:${valueColor}">${esc(value)}${unit ? ' ' + esc(unit) : ''}</span>
    </div>
  `;

  const infoNutricionalHTML = () => {
    if (!tNutri.estrategia && !tNutri.kcal) return '';
    return `
      <div style="margin-bottom:16px">
        ${tNutri.estrategia ? `<div style="font-size:10px;font-weight:800;padding:3px 10px;border-radius:999px;background:#0D2640;color:#fff;display:inline-block;margin-bottom:10px">${esc(tNutri.estrategia)}</div>` : ''}
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:10px">
          ${tNutri.kcal ? metricCard('KCAL', tNutri.kcal, '#0D2640') : ''}
          ${tNutri.proteina ? metricCard('PROTEÍNA', tNutri.proteina + 'P', '#0066CC') : ''}
          ${tNutri.carbos ? metricCard('CARBO', tNutri.carbos + 'C', '#2E9E70') : ''}
          ${tNutri.grasas ? metricCard('GRASAS', tNutri.grasas + 'G', '#CC6600') : ''}
        </div>
        ${tNutri.suple ? `<div style="font-size:10px;color:#4B5563"><b>Suplementación recomendada:</b> ${esc(tNutri.suple)}</div>` : ''}
      </div>
    `;
  };

  const infoClinicaHTML = () => {
    if (!clinico.retroalimentacion?.length && !clinico.diagnostico?.length && !clinico.objetivos?.length) return '';
    return `
      <details class="collapsible">
        <summary style="width:100%;box-sizing:border-box">
          <div style="display:flex;align-items:center;justify-content:space-between;padding:6px 0;font-size:12px;font-weight:800;letter-spacing:1px;color:#0D2640;text-transform:uppercase;width:100%;box-sizing:border-box">
            <span>Información clínica</span>
            <span style="font-size:10px;color:#6B7280;flex-shrink:0;padding:6px 8px">▼</span>
          </div>
        </summary>
        <div class="collapsed-content" style="padding:8px 16px">
          ${clinico.retroalimentacion?.length ? `
            <div style="padding-bottom:10px;margin-bottom:10px">
              <div style="font-size:9px;font-weight:800;letter-spacing:0.12em;text-transform:uppercase;color:#6B7280;margin-bottom:6px">RETROALIMENTACIÓN</div>
              ${clinico.retroalimentacion.map((item, i) => `
                <div style="display:flex;gap:8px;padding:5px 0;border-bottom:1px solid #F3F4F6">
                  <span style="width:16px;height:16px;border-radius:999px;background:#2E9E70;color:#fff;display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:800;flex-shrink:0">${i + 1}</span>
                  <span style="font-size:10px;color:#4B5563;line-height:1.4">${esc(item)}</span>
                </div>
              `).join('')}
            </div>
          ` : ''}
          ${clinico.diagnostico?.length ? `
            <div style="padding-bottom:10px;margin-bottom:10px">
              <div style="font-size:9px;font-weight:800;letter-spacing:0.12em;text-transform:uppercase;color:#6B7280;margin-bottom:6px">DIAGNÓSTICO</div>
              ${clinico.diagnostico.map((item, i) => `
                <div style="display:flex;gap:8px;padding:5px 0;border-bottom:1px solid #F3F4F6">
                  <span style="width:16px;height:16px;border-radius:999px;background:#0D2640;color:#fff;display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:800;flex-shrink:0">${i + 1}</span>
                  <span style="font-size:10px;color:#4B5563;line-height:1.4">${esc(item)}</span>
                </div>
              `).join('')}
            </div>
          ` : ''}
          ${clinico.objetivos?.length ? `
            <div style="padding-top:10px;margin-top:10px">
              <div style="font-size:9px;font-weight:800;letter-spacing:0.12em;text-transform:uppercase;color:#6B7280;margin-bottom:6px">OBJETIVOS Y PLAN A SEGUIR</div>
              ${clinico.objetivos.map((item, i) => `
                <div style="display:flex;gap:8px;padding:5px 0;border-bottom:1px solid #F3F4F6">
                  <span style="width:16px;height:16px;border-radius:999px;background:#0066CC;color:#fff;display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:800;flex-shrink:0">${i + 1}</span>
                  <span style="font-size:10px;color:#4B5563;line-height:1.4">${esc(item)}</span>
                </div>
              `).join('')}
            </div>
          ` : ''}
        </div>
      </details>
    `;
  };

  const tratamientoDeportivoHTML = () => {
    if (!tEntre.estrategia && !tEntre.dias) return '';
    return `
      <div style="margin-bottom:16px">
        ${tEntre.estrategia ? `<div style="font-size:10px;font-weight:800;padding:3px 10px;border-radius:999px;background:#0D2640;color:#fff;display:inline-block;margin-bottom:10px">${esc(tEntre.estrategia)}</div>` : ''}
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:10px">
          ${diasStat ? metricCard('DÍAS', diasStat, '#0066CC') : ''}
          ${cardioStat ? metricCard('CARDIO', cardioStat, '#2E9E70') : ''}
          ${tEntre.pasos ? metricCard('PASOS', tEntre.pasos, '#0D2640') : ''}
        </div>
        ${tEntre.rir ? `<div style="font-size:10px;color:#4B5563;margin-bottom:6px"><b>RIR objetivo:</b> ${esc(tEntre.rir)}</div>` : ''}
        ${tEntre.indic ? `<div style="font-size:10px;color:#4B5563"><b>Indicaciones:</b> ${esc(tEntre.indic)}</div>` : ''}
      </div>
    `;
  };

  return `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{margin:0;padding:0;box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{font-family:'Inter',system-ui,-apple-system,sans-serif;background:#F8F9FC;color:#0D2640;line-height:1.45;-webkit-font-smoothing:antialiased}
img{max-width:100%;display:block}
a{color:#0D2640;text-decoration:none}
.wrap{max-width:560px;margin:0 auto;padding:0 14px 0}
.app-footer{font-size:9px;letter-spacing:1px;color:#6B7280;font-weight:700;text-align:center;margin-top:0;text-transform:uppercase}
.app-footer-sub{font-size:8px;letter-spacing:0.8px;color:#9CA3AF;font-weight:600;text-align:center;margin-top:0;text-transform:uppercase}

.navbar{padding:16px 0 0 0;display:flex;justify-content:flex-end;align-items:center}
.hero{margin-bottom:16px}

.stats{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-top:14px}
.stat{background:#fff;border:1px solid #E8E8E8;border-radius:14px;padding:10px;text-align:center}
.stat span{font-size:9px;letter-spacing:1px;color:#6B7280;font-weight:700;display:block}
.stat b{font-size:14px;font-weight:800;margin-top:2px;display:block;color:#0D2640}

.training-card{background:#0066CC;border-radius:20px;padding:16px;color:#fff;margin-bottom:12px}
.training-header{display:flex;align-items:center;gap:8px;margin-bottom:4px}
.training-label{font-size:11px;font-weight:800;letter-spacing:0.16em;text-transform:uppercase;opacity:.8}
.training-title{font-size:20px;font-weight:900;line-height:1.1;margin-top:4px}
.training-list{margin-top:12px}
.training-item{padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.08)}
.training-item:last-child{border-bottom:none}
.training-item-meta{font-size:10px;color:rgba(255,255,255,0.6);margin-top:2px}
.training-badge{font-size:9px;font-weight:800;padding:2px 8px;border-radius:999px;background:#0B63CE;color:#fff;white-space:nowrap;margin-left:8px}

.section-card{background:#fff;border:1px solid #E8E8E8;border-radius:20px;padding:16px;margin-bottom:12px}
.section-title{font-size:11px;font-weight:800;letter-spacing:1px;color:#0D2640;margin-bottom:10px;text-transform:uppercase}

.supp-pill{font-size:9px;font-weight:800;padding:4px 10px;border-radius:999px;background:#2E9E70;color:#fff;white-space:nowrap}

.dia-section{margin-bottom:24px}
details{border:1px solid #E8E8E8;border-radius:12px;margin:0 0 10px 0;background:#fff}
summary{padding:11px 12px;font-weight:700;font-size:13px;cursor:pointer;list-style:none;color:#0D2640}
summary::-webkit-details-marker{display:none}
details[open] summary{border-bottom:1px solid #E8E8E8;background:#fafafa;border-radius:12px 12px 0 0}
.content{padding:10px 12px 12px 12px}
.day-details summary{display:flex;align-items:center;justify-content:space-between;border-radius:12px 12px 12px 12px}
.day-details[open] summary{background:#0D2640;color:#fff;border-radius:12px 12px 0 0;border-bottom:1px solid #F3F4F6}

/* Collapsible sections */
.collapsible{border:1px solid #E8E8E8;border-radius:16px;background:#fff;margin-bottom:12px;width:100%;box-sizing:border-box}
.collapsible summary{padding:12px 16px;cursor:pointer;list-style:none;font-size:12px;font-weight:800;letter-spacing:1px;color:#0D2640;display:flex;justify-content:space-between;align-items:center;text-transform:uppercase}
.collapsible summary::-webkit-details-marker{display:none}
.collapsible[open] summary{border-bottom:1px solid #E8E8E8}
.collapsible .collapsed-content{padding:0 16px 16px}

.day-nav select{width:100%;padding:10px 12px;border-radius:12px;border:1px solid #E8E8E8;background:#fff;font-size:12px;font-weight:700;color:#0D2640}

/* Guía */
.guia-outer{border:1px solid #E8E8E8;border-radius:16px;background:#fff;margin-bottom:12px}
.guia-outer > summary{padding:16px;cursor:pointer;list-style:none;color:#fff;background:#0066CC;border-radius:12px;display:flex;justify-content:space-between;align-items:center}
.guia-outer[open] > summary{border-bottom:1px solid #E8E8E8;background:#0066CC;border-radius:12px 12px 0 0}
.guia-outer > .guia-content{padding:12px}
.guia-inner{border:1px solid #E8E8E8;border-radius:12px;background:#fff;margin-bottom:8px}
.guia-inner > summary{padding:0;cursor:pointer;list-style:none;font-size:12px;font-weight:700;display:flex;align-items:center;justify-content:space-between;color:#0D2640;background:#fff;border-radius:12px}
.guia-inner[open] > summary{background:#F8F9FC;border-radius:12px 12px 0 0}
.guia-inner .guia-inner-content{padding:16px;font-size:12px;color:#4B5563;line-height:1.6}
</style>
</head>
<body>
<div class="wrap">
  <div class="navbar">
    ${logoHTML}
  </div>

  <!-- HERO -->
   ${heroHTML()}

    <!-- AVANCES -->
    <div style="margin-top:4px;margin-bottom:8px;font-size:11px;font-weight:800;letter-spacing:1px;color:#0D2640;text-transform:uppercase">Avances</div>
    ${avancesCard()}

    <!-- INFORMACIÓN CLÍNICA -->
    ${infoClinicaHTML()}

    <!-- TRATAMIENTO DEPORTIVO -->
    <div style="margin-top:4px;margin-bottom:8px;font-size:11px;font-weight:800;letter-spacing:1px;color:#0D2640;text-transform:uppercase">Tratamiento deportivo</div>
    ${tratamientoDeportivoHTML()}

    <!-- CALENTAMIENTO -->
    <div style="margin-top:4px;margin-bottom:8px;font-size:11px;font-weight:800;letter-spacing:1px;color:#0D2640;text-transform:uppercase">Calentamiento</div>
    ${calentamientoHTML()}

    <!-- CALENDARIO SEMANAL -->
    <div style="margin-top:4px;margin-bottom:8px;font-size:11px;font-weight:800;letter-spacing:1px;color:#0D2640;text-transform:uppercase">Calendario semanal</div>
    ${calendarioHTML()}

    <!-- TRATAMIENTO NUTRICIONAL -->
    <div style="margin-top:4px;margin-bottom:8px;font-size:11px;font-weight:800;letter-spacing:1px;color:#0D2640;text-transform:uppercase">Tratamiento nutricional</div>
    ${infoNutricionalHTML()}

    <!-- COMIDAS -->
    <div style="margin-top:4px;margin-bottom:8px;font-size:11px;font-weight:800;letter-spacing:1px;color:#0D2640;text-transform:uppercase">Comidas</div>
    ${comidasHTML()}

    <!-- SUPLEMENTOS -->
    <div style="margin-top:4px;margin-bottom:8px;font-size:11px;font-weight:800;letter-spacing:1px;color:#0D2640;text-transform:uppercase">Tratamiento de suplementación</div>
    ${suplementosHTML()}

    <!-- GUÍA -->
    ${guiaHTML()}
    <!-- GLOSARIO -->
    ${glosarioHTML()}

  <div class="app-footer">DOCFITNESS ${new Date().getFullYear()}</div>
   <div class="app-footer-sub" style="margin-top:4px">ESTÉTICA CORPORAL | MEDICINA | NUTRICIÓN | ENTRENAMIENTO</div>
   </div>
<script>
  function scheduleToggleResize() {
    setTimeout(notifyHeight, 10);
    setTimeout(notifyHeight, 350);
  }

  if (typeof ResizeObserver !== 'undefined' && document.body) {
    new ResizeObserver(notifyHeight).observe(document.body);
  }

  window.addEventListener('load', function() {
    setTimeout(notifyHeight, 10);
    setTimeout(notifyHeight, 350);
  });
  setTimeout(notifyHeight, 10);
  setTimeout(notifyHeight, 350);

  document.addEventListener('toggle', function(e) {
    if (e.target && e.target.tagName === 'DETAILS') {
      scheduleToggleResize();
    }
  }, true);

  document.addEventListener('click', function(e) {
    var d = e.target.closest('details');
    if (d) {
      scheduleToggleResize();
    }
  });

  function notifyHeight() {
    try {
      var h = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight);
      window.parent.postMessage({ type: 'RESIZE_IFRAME', height: h }, '*');
    } catch (e) {}
  }
</script>
</body>
</html>`;
};

export const downloadDashboardFitness = (data, fileName, mode = 'todo') => {
  try {
    const html = generateDashboardFitnessHTML(data, mode);
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const safeName = (fileName || data.person?.id || 'Paciente').replace(/[^a-zA-Z0-9-_]/g, '').trim() || 'Paciente';
    a.href = url;
    a.download = `Plan-${safeName}.html`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
    return true;
  } catch (err) {
    console.error('Error generating dashboard', err);
    const win = window.open('', '_blank');
    if (!win) return false;
    win.document.write(generateDashboardFitnessHTML(data, mode));
    win.document.close();
    return true;
  }
};
