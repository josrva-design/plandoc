// ==========================================
// EDITOR
// ==========================================

export interface Person {
  id: string;
  nombre: string;
  edad: string;
  estatura: string;
  pesoIni: string;
  nivel: string;
  objetivo: string;
  sexo: string;
  fechaNacimiento: string;
  pais: string;
  estado: string;
  celular: string;
  email: string;
  instagram: string;
  ocupacion: string;
  imc: string;
  grasa: string;
  musculo: string;
  cintura: string;
  cadera: string;
  nivelActividad: string;
  despertar: string;
  dormir: string;
  entrenamientoHorario: string;
  entrenamientoSesiones: string;
  entrenamientoDuracion: string;
  pasos: string;
  inicioTrabajo: string;
  recesoTrabajo: string;
  terminoTrabajo: string;
  tiemposComida: string;
  gustos: string;
  quienCocina: string;
  leGusta: string;
  noLeGusta: string;
  alergias: string;
  condicionMedica: string;
  actividad1: string;
  actividad2: string;
  app: string;
  appEstado: string;
  af: string;
  afEstado: string;
  medicacion: string;
  medicacionEstado: string;
  alergiasEstado: string;
  cirugias: string;
  cirugiasEstado: string;
  intolerancias: string;
  intoleranciasEstado: string;
  lesiones: string;
  lesionesEstado: string;
  laboratorios: string;
  laboratoriosEstado: string;
}

export interface NutritionData {
  estrategia: string;
  kcal: string;
  prot: string;
  carbs: string;
  grasas: string;
  suple: string;
  planPrevio: string;
  resultadosPrevios: string;
  queNoTeGusta: string;
  tipoPlan: string;
  caracteristica: string;
  interesSuplementos: string;
  suplementacionActual: string;
}

export interface TrainingData {
  estrategia: string;
  dias: string;
  cardio: string;
  pasos: string;
  rir: string;
  indic: string;
}

export interface CalendarDay {
  dia: string;
  dayKey: string;
  actividad: string;
  routineId: string | null;
}

export interface WarmupExercise {
  tipo: string;
  grupo: string;
  video: string;
  ejercicio: string;
  sets: string;
  reps: string;
  pausa: string;
  notas: string;
}

export interface WarmupBlock {
  general: WarmupExercise[];
  movilidad: WarmupExercise[];
  específico: WarmupExercise[];
}

export interface RoutineExercise {
  id: string;
  ejercicio: string;
  serie: string;
  reps: string;
  peso: string;
  descanso: string;
  rir: string;
  notas: string;
  tecnica?: string;
}

export interface RoutineBlock {
  id: string;
  label: string;
  group: string;
  exercises: RoutineExercise[];
}

export interface Routine {
  id: string;
  label: string;
  blocks: RoutineBlock[];
}

export interface FoodPortion {
  label: string;
  gramos: number;
  p: number;
  c: number;
  g: number;
  kcal: number;
}

export interface FoodItem {
  nombre: string;
  grupo: string;
  porciones: FoodPortion[];
}

export interface MealFood {
  foodId: string;
  portionLabel: string;
  grams: number;
  p: number;
  c: number;
  g: number;
  kcal: number;
}

export interface MealEditor {
  dayKey?: string;
  id?: string;
  time: string;
  hour?: string;
  tiempo?: string;
  kcal?: number;
  macros?: { proteinas?: number; carbos?: number; grasas?: number };
  menuType?: 'fijo' | 'armar';
  foods: Array<{
    name?: string;
    nombre?: string;
    grams?: string;
    unit?: string;
    kcal?: number;
    p?: string;
    c?: string;
    g?: string;
    cantidad?: string;
    porcion?: string;
    porcionBase?: string;
    foodId?: string;
  }>;
  menus?: Array<{
    id?: string;
    nombre?: string;
    alimentos?: MealEditor['foods'];
  }>;
}

export interface DayPlan {
  meals: Record<string, MealEditor[]>;
  routineId: string | null;
  supplementIds: string[];
}

export interface WeeklyPlan {
  monday: DayPlan;
  tuesday: DayPlan;
  wednesday: DayPlan;
  thursday: DayPlan;
  friday: DayPlan;
  saturday: DayPlan;
  sunday: DayPlan;
}

export interface Supplement {
  id: string;
  nombre: string;
  dosis: string;
  frecuencia: string;
  tomarCon: string;
  notas: string;
}

export interface Stats {
  peso: string;
  abdomen: string;
  grasaKg: string;
  grasaPorc: string;
  pliegue: string;
  avPeso: string;
  avAbd: string;
  avGrasaKg: string;
  avGrasaPorc: string;
  avPliegue: string;
  adherencia: string;
  nutricion: string;
  entreno: string;
  cardio: string;
  descanso: string;
}

export interface Feedback {
  r1: string;
  r2: string;
  r3: string;
}

export interface Diagnosis {
  d1: string;
  d2: string;
  d3: string;
}

export interface Objectives {
  o1: string;
  o2: string;
  o3: string;
}

export interface EvolutionCells {
  [key: string]: {
    peso?: number;
    abdomen?: number;
    grasaKg?: number;
    grasa_pct?: number;
    muscular?: number;
    cint_abd?: number;
    cadera?: number;
    [key: string]: number | undefined;
  };
}

export interface EvolutionData {
  dates: string[];
  cells: EvolutionCells;
  consultas: string[];
}

export interface EditorRoutine {
  id: string;
  nombre: string;
  titulo: string;
  ejercicios: any[];
}

export interface AppData {
  person: Person;
  prx: string;
  stats: Stats;
  nutrition: NutritionData;
  training: TrainingData;
  calendar: CalendarDay[];
  warmupUpper: WarmupBlock;
  warmupLower: WarmupBlock;
  routines: EditorRoutine[];
  activeRoutineId: string | null;
  meals: MealEditor[];
  supplements: Supplement[];
  feedback: Feedback;
  diagnosis: Diagnosis;
  objectives: Objectives;
 habits: any[];
 classifications: Record<string, string[]>;
 evolution: EvolutionData;
 fechaConsulta: string;
}

// ==========================================
// PRODUCTO / CLIENTE
// ==========================================

export interface MealClient {
  dayKey: string;
  time: string;
  hour: string;
  kcal: number;
  macros?: { proteinas: number; carbos: number; grasas: number };
  foods: Array<{
    name: string;
    grams: string;
    unit?: string;
    kcal?: number;
    macros?: { proteinas: number; carbos: number; grasas: number };
  }>;
  menuType?: 'fijo' | 'armar';
  menus?: Array<{ id?: string; nombre?: string; alimentos?: MealClient['foods'] }>;
}

export interface ExerciseClient {
  ejercicio: string;
  secuencia: string;
  tecnica: string;
  sets: string;
  reps: string;
  descanso: string;
  rir: string;
  nota: string;
}

export interface PatientEjercicio {
  codigo: string;
  nombre: string;
  badgeTecnica: string;
  prescripcion: string;
  grupo?: string;
  subtipo?: string;
}

export type BloqueTipo = 'BISERIE' | 'TRISERIE' | 'SERIE SIMPLE' | 'ELIGE 1 OPCIÓN';

export interface PatientBloque {
  letra: string;
  tipo: BloqueTipo;
  indicacion: string;
  ejercicios: PatientEjercicio[];
}

export type FaseId = 'CG' | 'ED' | 'CE' | 'SA' | 'PRINCIPAL' | 'ABD';

export interface PatientFase {
  id: FaseId;
  nombre: string;
  badgeColor: string;
  bloques: PatientBloque[];
  grupo?: 'lower' | 'upper' | 'main';
}

export interface DayRoutine {
  tipo: 'lower' | 'upper' | 'rest' | 'full';
  actividad: string;
  titulo: string;
  subtitulo: string;
  fases: PatientFase[];
}

export interface SupplementClient {
  nombre: string;
  dosis: string;
  hora: string;
  tiempo: string;
}

export interface WarmupPhase {
  fase: 'GENERAL' | 'MOVILIDAD' | 'ESPECÍFICO';
  opciones: Array<{ ejercicio: string; detalle: string; tipo: string; grupo: string }>;
  individuales: Array<{ ejercicio: string; detalle: string; tipo: string; grupo: string }>;
}

export interface AvanceMedida {
  label: string;
  anterior: string;
  actual: string;
  delta: number;
}

export interface AvancePeso extends AvanceMedida {}

export interface EstadisticasClient {
  adherencia: number;
  nutricion: number;
  entrenamiento: number;
  cardio: number;
  descanso: string;
}

export interface TratamientoNutricional {
  estrategia: string;
  kcal: string;
  proteina: string;
  carbos: string;
  grasas: string;
}

export interface TratamientoEntrenamiento {
  estrategia: string;
  dias: string;
  cardio: string;
  pasos: string;
}

export interface Clinico {
  retroalimentacion: string[];
  diagnostico: string[];
  objetivos: string[];
}

export interface WarmupPhasePDF {
  id: string;
  nombre: string;
  badgeColor: string;
  bloques: {
    letra: string;
    tipo: string;
    ejercicios: {
      codigo: string;
      nombre: string;
      prescripcion: string;
    }[];
  }[];
}

export interface GuiaItem {
  titulo: string;
  contenido: string;
}

export interface GlosarioItem {
  term: string;
  def: string;
  cat?: string;
  subtitle?: string;
  body?: string;
  example?: string;
}

export interface ClientPlan {
  person: {
    nombre: string;
    objetivo: string;
    pasos?: string;
  };
  proximaConsulta: string | null;
  calendar: CalendarDay[];
  meals: MealClient[];
  routines: Record<string, DayRoutine>;
  supplements: SupplementClient[];
  stats: {
    adherencia: number;
  };
  avances: {
    peso: AvancePeso;
    abdomen?: AvanceMedida;
    grasaKg?: AvanceMedida;
    grasaPct?: AvanceMedida;
    pliegue?: AvanceMedida;
  };
  estadisticas: EstadisticasClient;
  tratamientoNutricional: TratamientoNutricional;
  tratamientoEntrenamiento: TratamientoEntrenamiento;
  clinico: Clinico;
  fechaConsulta: string;
  warmupUpper: PatientFase[];
  warmupLower: PatientFase[];
}
