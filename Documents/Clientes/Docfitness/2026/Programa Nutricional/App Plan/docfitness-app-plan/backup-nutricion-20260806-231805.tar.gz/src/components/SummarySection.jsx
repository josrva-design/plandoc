import React, { useState, useEffect, useMemo, useRef } from 'react';
import SectionTitle from './SectionTitle.jsx';
import AvancesCards from './AvancesCards.jsx';
import MacroBars from './MacroBars.jsx';
import { useAppContext } from '../context/AppContext.jsx';
import { getTotalKcalFromMeals, getTotalMacrosFromMeals } from '../utils/nutritionHelpers.js';

export default function SummarySection({ printable = false }) {
  const { data, setters } = useAppContext();
  const d = data || {};
  const P = ({ v, ph }) => v ? v : <span className="opacity-20">{ph}</span>;

  const person = d.person || {};
  const stats = d.stats || {};
  const nutrition = d.nutrition || {};
  const training = d.training || {};
  const evolution = d.evolution || {};
  const meals = d.meals || [];

  const consultas = evolution.consultas || [];
  const cells = evolution.cells || {};

  const mealKcal = useMemo(() => getTotalKcalFromMeals(meals), [meals]);
  const mealMacros = useMemo(() => getTotalMacrosFromMeals(meals), [meals]);

  const [manualKcal, setManualKcal] = useState(null);
  const [manualProte, setManualProte] = useState(null);
  const [manualCarbs, setManualCarbs] = useState(null);
  const [manualGrasas, setManualGrasas] = useState(null);

  const effectiveKcal = manualKcal !== null ? manualKcal : (mealKcal || nutrition.kcal || 0);
  const effectiveProte = manualProte !== null ? manualProte : (mealMacros.p || nutrition.prot || 0);
  const effectiveCarbs = manualCarbs !== null ? manualCarbs : (mealMacros.c || nutrition.carbs || 0);
  const effectiveGrasas = manualGrasas !== null ? manualGrasas : (mealMacros.g || nutrition.grasas || 0);

  const handleKcalChange = (val) => {
    const num = Number(val) || 0;
    setManualKcal(num);
    if (setters.setNutrition) setters.setNutrition(prev => ({ ...prev, kcal: num }));
  };
  const handleProteChange = (val) => {
    const num = Number(val) || 0;
    setManualProte(num);
    if (setters.setNutrition) setters.setNutrition(prev => ({ ...prev, prot: num }));
  };
  const handleCarbsChange = (val) => {
    const num = Number(val) || 0;
    setManualCarbs(num);
    if (setters.setNutrition) setters.setNutrition(prev => ({ ...prev, carbs: num }));
  };
  const handleGrasasChange = (val) => {
    const num = Number(val) || 0;
    setManualGrasas(num);
    if (setters.setNutrition) setters.setNutrition(prev => ({ ...prev, grasas: num }));
  };

  const protePct = useMemo(() => {
    if (!effectiveKcal || !effectiveProte) return '0%';
    return Math.round((effectiveProte * 4 / effectiveKcal) * 100) + '%';
  }, [effectiveKcal, effectiveProte]);

  const carbsPct = useMemo(() => {
    if (!effectiveKcal || !effectiveCarbs) return '0%';
    return Math.round((effectiveCarbs * 4 / effectiveKcal) * 100) + '%';
  }, [effectiveKcal, effectiveCarbs]);

  const grasasPct = useMemo(() => {
    if (!effectiveKcal || !effectiveGrasas) return '0%';
    return Math.round((effectiveGrasas * 9 / effectiveKcal) * 100) + '%';
  }, [effectiveKcal, effectiveGrasas]);

  const macroPctMap = useMemo(() => ({
    protePct: protePct,
    carbsPct: carbsPct,
    grasasPct: grasasPct,
  }), [protePct, carbsPct, grasasPct]);

  const fechaConsulta = d.fechaConsulta ? new Date(d.fechaConsulta + 'T00:00:00') : new Date();
  const fechaActual = fechaConsulta.toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' });
  const prox = new Date(fechaConsulta);
  prox.setMonth(prox.getMonth() + 1);
  const proxima = prox.toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' });

  const [retroItems, setRetroItems] = useState(() => {
    const items = [d.feedback?.r1, d.feedback?.r2, d.feedback?.r3].filter(Boolean);
    return items.length > 0 ? items : [''];
  });

  const [diagItems, setDiagItems] = useState(() => {
    const items = [d.diagnosis?.d1, d.diagnosis?.d2, d.diagnosis?.d3].filter(Boolean);
    return items.length > 0 ? items : [''];
  });

  const [objItems, setObjItems] = useState(() => {
    const items = [d.objectives?.o1, d.objectives?.o2, d.objectives?.o3].filter(Boolean);
    return items.length > 0 ? items : [''];
  });

  const settersRef = useRef(setters);
  settersRef.current = setters;

  useEffect(() => {
    if (settersRef.current.setFeedback) {
      const obj = {};
      retroItems.forEach((v, i) => { obj[`r${i + 1}`] = v; });
      if (JSON.stringify(obj) !== JSON.stringify(d.feedback || {})) {
        settersRef.current.setFeedback(obj);
      }
    }
  }, [retroItems]);

  useEffect(() => {
    if (settersRef.current.setDiagnosis) {
      const obj = {};
      diagItems.forEach((v, i) => { obj[`d${i + 1}`] = v; });
      if (JSON.stringify(obj) !== JSON.stringify(d.diagnosis || {})) {
        settersRef.current.setDiagnosis(obj);
      }
    }
  }, [diagItems]);

  useEffect(() => {
    if (settersRef.current.setObjectives) {
      const obj = {};
      objItems.forEach((v, i) => { obj[`o${i + 1}`] = v; });
      if (JSON.stringify(obj) !== JSON.stringify(d.objectives || {})) {
        settersRef.current.setObjectives(obj);
      }
    }
  }, [objItems]);

  const handleKeyDown = (e, items, setItems, idx) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      setItems(prev => {
        const next = [...prev, ''];
        setTimeout(() => {
          const container = e.target.closest('.space-y-1');
          if (container) {
            const allInputs = Array.from(container.querySelectorAll('input'));
const target = allInputs[prev.length];
            if (target && target.isConnected) target.focus();
           }
         }, 0);
         return next;
      });
    } else if (e.key === 'Backspace' && e.target.value === '' && items.length > 1) {
      setItems(prev => {
        const next = prev.slice(0, -1);
        setTimeout(() => {
          const container = e.target.closest('.space-y-1');
          if (container) {
            const allInputs = Array.from(container.querySelectorAll('input'));
            const target = allInputs[allInputs.length - 1];
            if (target && target.isConnected) target.focus();
          }
        }, 0);
        return next;
      });
    }
  };

  const handleChange = (e, idx, items, setItems) => {
    const next = [...items];
    next[idx] = e.target.value;
    setItems(next);
  };

  const renderList = (items, setItems, placeholderBase) => {
    const placeholders = [
      'Evaluación inicial',
      'Progreso observado',
      'Áreas de mejora'
    ];
    
    return (
      <div className="space-y-1">
        {items.map((val, idx) => (
          <div key={idx} className="flex items-start gap-2">
            <span className="typo-label mt-0.5 w-5 text-right">{idx + 1}.</span>
            <input
              type="text"
              value={val}
              onChange={(e) => handleChange(e, idx, items, setItems)}
              onKeyDown={(e) => handleKeyDown(e, items, setItems, idx)}
              placeholder={!val ? placeholders[idx] || '' : ''}
              className="flex-1 w-full bg-transparent outline-none typo-input border-b border-transparent focus:border-[var(--color-primary)] input-placeholder list-input"
            />
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className={printable ? "w-full bg-white text-[#0D2640] font-[Inter] p-4" : "w-full bg-white text-[#0D2640] font-[Inter] p-4"}>
      <div className="flex justify-between items-end">
        <div>
          <h1 className="premium-page-title">{fechaActual}</h1>
          {!printable && <p className="premium-subtitle">Resumen general del plan.</p>}
        </div>
        <div className="text-right">
          <p className="typo-label">Próxima Actualización</p>
          <p className={printable ? "text-base text-[#0066CC] mt-1" : "typo-value-lg text-[#0066CC] mt-1"}>{proxima}</p>
        </div>
      </div>

      <div className={printable ? "mt-3" : "mt-6"}>
        <SectionTitle>Perfil</SectionTitle>
        <div className={printable ? "grid grid-cols-4 gap-2" : "grid grid-cols-4 gap-2"}>
          {[
            ["Nombre", person.nombre, "Nombre completo"],
            ["Edad", person.edad, "25"],
            ["Contacto", person.celular, "55XXXXXXXXX"],
            ["País/Región", person.pais, "México"],
            ["Act. Física 1", person.actividad1, "Act. Física 1"],
            ["Act. Física 2", person.actividad2, "Act. Física 2"],
            ["Alergias", person.alergias, "Ninguna"],
            ["Condición Méd.", person.condicionMedica, "Ninguna"],
          ].map(([label, value, refVal])=>(
            <div key={label} className="premium-card">
              <p className="typo-label">{label}</p>
              <p className={printable ? "text-sm mt-0.5" : "typo-value-md mt-1"}><P v={value} ph={refVal} /></p>
            </div>
          ))}
        </div>
      </div>

      <AvancesCards data={data} printable={printable} />
      <MacroBars stats={stats} printable={printable} />

      <div className={printable ? "mt-4" : "mt-6"}>
        <SectionTitle>Tratamiento Nutricional</SectionTitle>
        <div className={printable ? "grid grid-cols-5 gap-2" : "grid grid-cols-5 gap-2"}>
          <div className={`bg-[#2E9E70] text-white rounded-2xl text-center ${printable ? 'px-4 py-3' : 'px-4 py-4'}`}>
            <p className="typo-card-label-white">Estrategia</p>
            <p className={printable ? "text-sm mt-1.5" : "typo-value-lg mt-2"}><P v={nutrition.estrategia} ph="Mantenimiento" /></p>
            {!printable && <div className="mt-3 h-1 bg-white/20 rounded-full overflow-hidden"><div className="h-full bg-white w-[70%]" /></div>}
          </div>
          <div className="nutrition-metric-card text-center">
            <span className="typo-label">KCAL</span>
            <input
              type="number"
              value={effectiveKcal}
              onChange={(e) => handleKcalChange(e.target.value)}
              className="nutrition-metric-card__value nutrition-metric-card__value--kcal mt-1 w-full bg-transparent outline-none text-center"
            />
            <p className={printable ? "text-[10px] mt-1 opacity-60" : "typo-muted-sm opacity-60 mt-1"}>Meta Diaria</p>
          </div>
          <div className={`col-span-3 flex ${printable ? '' : ''}`}>
            {[
              ["Proteína (g)", effectiveProte, protePct, "140", "28%", handleProteChange],
              ["Carbohidratos (g)", effectiveCarbs, carbsPct, "220", "45%", handleCarbsChange],
              ["Grasas (g)", effectiveGrasas, grasasPct, "55", "27%", handleGrasasChange],
            ].map(([l,k,pk,rv,rp,handler], idx, arr)=>(
              <div key={l} className={`nutrition-metric-card flex-1 text-center ${printable ? 'p-3' : 'p-4'} ${idx < arr.length - 1 ? 'border-r border-[#E8E8E8]' : ''}`}>
                <span className="typo-label">{l}</span>
                <input
                  type="number"
                  value={k}
                  onChange={(e) => handler(e.target.value)}
                  className={`nutrition-metric-card__value ${printable ? 'text-sm' : 'typo-value-lg'} mt-1 w-full bg-transparent outline-none text-center`}
                  style={{color: idx === 0 ? '#0066CC' : idx === 1 ? '#2E9E70' : '#CC6600'}}
                />
                <p className={`nutrition-metric-card__value ${printable ? 'text-sm' : 'typo-value-lg'} mt-0.5`} style={{color: idx === 0 ? '#0066CC' : idx === 1 ? '#2E9E70' : '#CC6600'}}>{pk}</p>
                <div className={printable ? "mt-1 h-1 w-10 mx-auto rounded-full overflow-hidden" : "mt-2 h-1 w-12 mx-auto rounded-full overflow-hidden"} style={{background: idx === 0 ? '#0066CC' : idx === 1 ? '#2E9E70' : '#CC6600'}}><div className="h-full bg-white/30 rounded-full" style={{ width: `${pk}%` }} /></div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className={printable ? "mt-4" : "mt-6"}>
        <SectionTitle>Tratamiento de Entrenamiento</SectionTitle>
        <div className="flex gap-2">
          <div className={`bg-[#0066CC] text-white rounded-2xl text-center ${printable ? 'px-4 py-3' : 'px-4 py-4'}`}><p className="typo-card-label-white">Estrategia</p><p className={printable ? "text-sm mt-1.5" : "typo-value-lg mt-2"}><P v={training.estrategia} ph="Fuerza" /></p></div>
          <div className={`premium-card text-center`}><p className="typo-label">Días</p><p className={printable ? "text-sm mt-1.5" : "typo-value-lg mt-2"}><P v={training.dias} ph="4" /></p><div className={printable ? "mt-1 h-1 w-full bg-[#E8E8E8] rounded-full overflow-hidden" : "mt-2 h-1.5 w-full bg-[#E8E8E8] rounded-full overflow-hidden"}><div className="h-full bg-[#0D2640] rounded-full" style={{ width: `${(training.dias || 0) * 20}%` }} /></div></div>
          <div className="flex-1 grid grid-cols-2 gap-2">
            <div className="premium-card text-center"><p className="typo-label">Cardio</p><p className={printable ? "text-sm mt-1.5" : "typo-value-lg mt-2"}><P v={training.cardio} ph="30 min" /></p></div>
            <div className="premium-card text-center"><p className="typo-label">Pasos</p><p className={printable ? "text-sm mt-1.5" : "typo-value-lg mt-2"}><P v={training.pasos} ph="7,000" /></p>{!printable && <div className="mt-2 h-1 bg-[#E8E8E8] rounded-full overflow-hidden"><div className="h-full bg-[#0D2640] w-[65%]" /></div>}</div>
          </div>
        </div>
      </div>

      {!printable && (
        <div className="mt-6 space-y-6">
          <div>
            <SectionTitle>Retroalimentación</SectionTitle>
            {renderList(retroItems, setRetroItems, 'Describe tu evaluación inicial')}
          </div>
          <div>
            <SectionTitle>Diagnóstico</SectionTitle>
            {renderList(diagItems, setDiagItems, 'Describe la composición corporal')}
          </div>
          <div>
            <SectionTitle>Objetivos y plan a seguir</SectionTitle>
            {renderList(objItems, setObjItems, 'Describe tu objetivo principal')}
          </div>
        </div>
      )}
    </div>
  );
}
