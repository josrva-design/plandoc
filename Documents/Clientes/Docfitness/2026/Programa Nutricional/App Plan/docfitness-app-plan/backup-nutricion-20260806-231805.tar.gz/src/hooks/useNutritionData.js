import { useCallback } from 'react';
import { findFoodByName, getUnidadFromLabel, buildAlimentoMacros } from '../utils/nutritionHelpers.js';

const EMPTY_ALIMENTO = () => ({ gramos: '', porcion: '', porcionBase: '', cantidad: '1', nombre: '', p: '', c: '', g: '', kcal: '' });

export default function useNutritionData(data, setters, showToast) {
  const { meals } = data;
  const { setMeals } = setters;

  const updateMeal = useCallback((idx, field, value) => {
    setMeals(prev => prev.map((meal, i) => (i === idx ? { ...meal, [field]: value } : meal)));
  }, [setMeals]);

  const updateMenuName = useCallback((mealIdx, menuId, nombre) => {
    setMeals(prev => prev.map((meal, i) => {
      if (i !== mealIdx) return meal;
      const menus = Array.isArray(meal.menus) ? meal.menus : [];
      return { ...meal, menus: menus.map((m) => (m.id === menuId ? { ...m, nombre } : m)) };
    }));
  }, [setMeals]);

  const addMeal = useCallback((dayKey) => {
    const tiempos = ['DESAYUNO', 'COMIDA', 'CENA', 'SNACK', 'PRE', 'POST', 'AYUNAS', 'ANTES DORMIR'];
    const tiempo = tiempos[Math.floor(Math.random() * tiempos.length)];
    const newMeal = { id: Date.now().toString(), dayKey, hora: '12:00', tiempo, menus: [{ id: Date.now().toString() + '-menu', nombre: 'Menú A', alimentos: [EMPTY_ALIMENTO()] }] };
    setMeals(prev => [...prev, newMeal]);
    showToast('Comida agregada');
  }, [setMeals, showToast]);

  const removeMeal = useCallback((idx) => {
    setMeals(prev => prev.filter((_, i) => i !== idx));
    showToast('Comida eliminada');
  }, [setMeals, showToast]);

  const addMenu = useCallback((mealIdx) => {
    setMeals(prev => prev.map((meal, i) => {
      if (i !== mealIdx) return meal;
      const menus = Array.isArray(meal.menus) ? meal.menus : [];
      const letter = String.fromCharCode(65 + menus.length);
      const newMenu = { id: Date.now().toString(), nombre: 'Menú ' + letter, alimentos: [EMPTY_ALIMENTO()] };
      return { ...meal, menus: [...menus, newMenu] };
    }));
    showToast('Menú agregado');
  }, [setMeals, showToast]);

  const removeMenu = useCallback((mealIdx, menuIdx) => {
    setMeals(prev => prev.map((meal, i) => {
      if (i !== mealIdx) return meal;
      const menus = Array.isArray(meal.menus) ? meal.menus : [];
      const newMenus = menus.filter((_, j) => j !== menuIdx);
      if (newMenus.length === 0) return null;
      return { ...meal, menus: newMenus };
    }).filter(Boolean));
    showToast('Menú eliminado');
  }, [setMeals, showToast]);

  const addAlimento = useCallback((mealIdx, menuIdx) => {
    setMeals(prev => prev.map((meal, i) => {
      if (i !== mealIdx) return meal;
      const menus = Array.isArray(meal.menus) ? meal.menus : [];
      return {
        ...meal,
        menus: menus.map((m, j) => {
          if (j !== menuIdx) return m;
          const alimentos = Array.isArray(m.alimentos) ? m.alimentos : [];
          return { ...m, alimentos: [...alimentos, EMPTY_ALIMENTO()] };
        }),
      };
    }));
    showToast('Alimento agregado');
  }, [setMeals, showToast]);

  const removeAlimento = useCallback((mealIdx, menuIdx, alimIdx) => {
    setMeals(prev => prev.map((meal, i) => {
      if (i !== mealIdx) return meal;
      const menus = Array.isArray(meal.menus) ? meal.menus : [];
      const updatedMenus = menus.map((m, j) => {
        if (j !== menuIdx) return m;
        const alimentos = Array.isArray(m.alimentos) ? m.alimentos : [];
        const newAlimentos = alimentos.filter((_, k) => k !== alimIdx);
        return { ...m, alimentos: newAlimentos };
      }).filter(m => (m.alimentos || []).length > 0);
      if (updatedMenus.length === 0) return null;
      return { ...meal, menus: updatedMenus };
    }).filter(Boolean));
    showToast('Alimento eliminado');
  }, [setMeals, showToast]);

  const reorderAlimento = useCallback((fromUid, toUid) => {
    const parseUid = (uid) => {
      const parts = String(uid).split('-');
      return {
        mealIdx: parseInt(parts[1], 10),
        menuIdx: parseInt(parts[2], 10),
        alimIdx: parseInt(parts[3], 10),
      };
    };
    const from = parseUid(fromUid);
    const to = parseUid(toUid);
    if (from.mealIdx !== to.mealIdx || from.menuIdx !== to.menuIdx) return;
    if (from.alimIdx === to.alimIdx) return;
    setMeals(prev => prev.map((meal, i) => {
      if (i !== from.mealIdx) return meal;
      const menus = Array.isArray(meal.menus) ? meal.menus : [];
      return {
        ...meal,
        menus: menus.map((m, j) => {
          if (j !== from.menuIdx) return m;
          const alimentos = Array.isArray(m.alimentos) ? m.alimentos : [];
          const next = [...alimentos];
          const [moved] = next.splice(from.alimIdx, 1);
          next.splice(to.alimIdx, 0, moved);
          return { ...m, alimentos: next };
        }),
      };
    }));
  }, [setMeals]);

  const updateMenu = useCallback((mealIdx, menuId, nombre) => {
    setMeals(prev => prev.map((meal, i) => {
      if (i !== mealIdx) return meal;
      const menus = Array.isArray(meal.menus) ? meal.menus : [];
      return { ...meal, menus: menus.map((m) => (m.id === menuId ? { ...m, nombre } : m)) };
    }));
  }, [setMeals]);

  const updateAlimentoDeep = useCallback((mealIdx, menuIdx, alimIdx, updater) => {
    setMeals(prev => prev.map((meal, i) => {
      if (i !== mealIdx) return meal;
      const menus = Array.isArray(meal.menus) ? meal.menus : [];
      return {
        ...meal,
        menus: menus.map((m, j) => {
          if (j !== menuIdx) return m;
          const alimentos = Array.isArray(m.alimentos) ? m.alimentos : [];
          return { ...m, alimentos: alimentos.map((a, k) => (k === alimIdx ? updater(a) : a)) };
        }),
      };
    }));
  }, [setMeals]);

  const autofillAlimento = useCallback((mealIdx, menuIdx, alimIdx, food) => {
    if (!food || !food.porciones || food.porciones.length === 0) return;
    const defaultPorcion = food.porciones[0];
    updateAlimentoDeep(mealIdx, menuIdx, alimIdx, (a) => ({
      ...a,
      nombre: food.nombre,
      porcion: defaultPorcion.label,
      porcionBase: defaultPorcion.label,
      cantidad: '1',
      ...buildAlimentoMacros(a, defaultPorcion, 1),
    }));
  }, [updateAlimentoDeep]);

  const onPorcionCantidadChange = useCallback((mealIdx, menuIdx, alimIdx, newCantidad) => {
    updateAlimentoDeep(mealIdx, menuIdx, alimIdx, (a) => {
      const cantidad = parseFloat(newCantidad) || 1;
      const food = findFoodByName(a.nombre);
      if (!food || !food.porciones || food.porciones.length === 0) {
        return { ...a, cantidad: newCantidad };
      }
      const porcion = food.porciones.find((p) => p.label === a.porcionBase) || food.porciones[0];
      const unidad = getUnidadFromLabel(porcion.label);
      const plural = cantidad > 1 ? 's' : '';
      return {
        ...a,
        cantidad: newCantidad,
        porcion: `${cantidad} ${unidad}${plural}`,
        ...buildAlimentoMacros(a, porcion, cantidad),
      };
    });
  }, [updateAlimentoDeep]);

  const recalculateAlimento = useCallback((mealIdx, menuIdx, alimIdx, newGramos) => {
    updateAlimentoDeep(mealIdx, menuIdx, alimIdx, (a) => {
      const formatted = newGramos ? `${newGramos}g` : '';
      const updated = { ...a, gramos: formatted };
      const food = findFoodByName(a.nombre);
      if (!food || !newGramos || !food.porciones || food.porciones.length === 0) {
        return updated;
      }
      const base = food.porciones.find((p) => p.label === a.porcionBase) || food.porciones[0];
      const ratio = parseFloat(newGramos) / base.gramos;
      const cantidad = parseFloat(ratio.toFixed(2));
      const unidad = getUnidadFromLabel(base.label);
      const plural = cantidad > 1 ? 's' : '';
      return {
        ...updated,
        porcion: `${cantidad} ${unidad}${plural}`,
        cantidad: cantidad.toString(),
        p: (base.p * ratio).toFixed(1),
        c: (base.c * ratio).toFixed(1),
        g: (base.g * ratio).toFixed(1),
        kcal: Math.round(base.kcal * ratio),
      };
    });
  }, [updateAlimentoDeep]);

  const updateMenuType = useCallback((mealIdx, menuType) => {
    setMeals(prev => prev.map((meal, i) => {
      if (i !== mealIdx) return meal;
      return { ...meal, menuType };
    }));
  }, [setMeals]);

  const addFood = useCallback((mealIdx) => {
    setMeals(prev => prev.map((meal, i) => {
      if (i !== mealIdx) return meal;
      const foods = Array.isArray(meal.foods) ? meal.foods : [];
      return { ...meal, foods: [...foods, EMPTY_ALIMENTO()] };
    }));
    showToast('Alimento agregado');
  }, [setMeals, showToast]);

  const removeFood = useCallback((mealIdx, foodIdx) => {
    setMeals(prev => prev.map((meal, i) => {
      if (i !== mealIdx) return meal;
      const foods = Array.isArray(meal.foods) ? meal.foods : [];
      return { ...meal, foods: foods.filter((_, k) => k !== foodIdx) };
    }));
    showToast('Alimento eliminado');
  }, [setMeals, showToast]);

  const updateFood = useCallback((mealIdx, foodIdx, updater) => {
    setMeals(prev => prev.map((meal, i) => {
      if (i !== mealIdx) return meal;
      const foods = Array.isArray(meal.foods) ? meal.foods : [];
      return { ...meal, foods: foods.map((f, k) => (k === foodIdx ? updater(f) : f)) };
    }));
  }, [setMeals]);

  const reorderFood = useCallback((fromUid, toUid) => {
    const parseUid = (uid) => {
      const parts = String(uid).split('-');
      return {
        mealIdx: parseInt(parts[1], 10),
        foodIdx: parseInt(parts[2], 10),
      };
    };
    const from = parseUid(fromUid);
    const to = parseUid(toUid);
    if (from.mealIdx !== to.mealIdx || from.foodIdx === to.foodIdx) return;
    setMeals(prev => prev.map((meal, i) => {
      if (i !== from.mealIdx) return meal;
      const foods = Array.isArray(meal.foods) ? meal.foods : [];
      const next = [...foods];
      const [moved] = next.splice(from.foodIdx, 1);
      next.splice(to.foodIdx, 0, moved);
      return { ...meal, foods: next };
    }));
  }, [setMeals]);

  return {
    updateMeal,
    updateMenuName,
    addMeal,
    removeMeal,
    addMenu,
    removeMenu,
    addAlimento,
    removeAlimento,
    updateMenu,
    updateAlimentoDeep,
    autofillAlimento,
    onPorcionCantidadChange,
    recalculateAlimento,
    reorderAlimento,
    updateMenuType,
    addFood,
    removeFood,
    updateFood,
    reorderFood,
  };
}
