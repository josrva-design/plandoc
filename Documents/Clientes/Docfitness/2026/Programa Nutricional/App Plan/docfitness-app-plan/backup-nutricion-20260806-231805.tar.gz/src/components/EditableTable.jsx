import React, { useState, useMemo } from "react";
import IconX from "./ui/IconX.jsx";

export default function EditableTable({
  columns,
  rows,
  getRowId,
  groupBy,
  groupConfig,
  activeGroup,
  onGroupChange,
  onAddRow,
  onUpdateRow,
  onRemoveRow,
  onReorder,
  emptyText,
  addButtonLabel,
  showGroupPills,
  dragBetweenGroups = false,
  onGroupLabelChange,
  groupAddRow,
  groupRemoveRow,
  groupAddRowLabel = "+ Alimento",
  groupHora,
  onGroupHoraChange,
  headerStyle,
  headerClassName,
}) {
  const [dragUid, setDragUid] = useState(null);
  const [dropUid, setDropUid] = useState(null);
  const [editingGroupKey, setEditingGroupKey] = useState(null);
  const [groupLabelDraft, setGroupLabelDraft] = useState("");
  const dragCounterRef = React.useRef(0);

  const startEditingGroup = (key, currentLabel) => {
    setEditingGroupKey(key);
    setGroupLabelDraft(currentLabel || "");
  };

  const commitGroupLabel = (key) => {
    if (onGroupLabelChange) onGroupLabelChange(key, groupLabelDraft);
    setEditingGroupKey(null);
    setGroupLabelDraft("");
  };

  const handleDragStart = (uid) => (e) => {
    const handle = e.target.closest("[data-drag-handle]");
    if (!handle) {
      e.preventDefault();
      return;
    }
    e.dataTransfer.effectAllowed = "move";
    setDragUid(uid);
    dragCounterRef.current = 0;
  };

  const handleDragOver = (uid) => (e) => {
    e.preventDefault();
    if (!dragUid || dragUid === uid) return;
    if (!dragBetweenGroups && groupBy) {
      const dragRow = rows.find((r) => getRowId(r, -1) === dragUid);
      const targetRow = rows.find((r) => getRowId(r, -1) === uid);
      if (!dragRow || !targetRow) return;
      if (dragRow[groupBy] !== targetRow[groupBy]) return;
    }
    setDropUid(uid);
  };

  const handleDrop = (targetUid) => (e) => {
    e.preventDefault();
    if (!dragUid || dragUid === targetUid || !onReorder) return;
    onReorder(dragUid, targetUid);
    setDragUid(null);
    setDropUid(null);
    dragCounterRef.current = 0;
  };

  const handleDragEnd = () => {
    setDragUid(null);
    setDropUid(null);
    dragCounterRef.current = 0;
  };

  const handleDragEnter = () => {
    dragCounterRef.current += 1;
  };

  const handleDragLeave = (e) => {
    if (e.currentTarget.contains(e.relatedTarget)) return;
    dragCounterRef.current -= 1;
    if (dragCounterRef.current === 0) {
      setDropUid(null);
    }
  };

  const shouldShowGroupHeader = (idx) => {
    if (!groupBy || !groupConfig) return false;
    if (idx === 0) return true;
    const current = rows[idx]?.[groupBy];
    const previous = rows[idx - 1]?.[groupBy];
    return current !== previous;
  };

  const groupRows = useMemo(() => {
    if (!groupBy || !groupConfig) return [{ key: null, rows }];
    return Object.keys(groupConfig).map((key) => ({
      key,
      rows: rows.filter((r) => r[groupBy] === key),
    }));
  }, [rows, groupBy, groupConfig]);

  return (
    <div>
      {showGroupPills && groupConfig && (
        <div className="flex items-center gap-2 mb-4">
          <span className="typo-label">AGREGAR A:</span>
          {Object.entries(groupConfig).map(([key, config]) => (
            <button
              key={key}
              onClick={() => onGroupChange && onGroupChange(key)}
              className="pill"
              style={{
                background: activeGroup === key ? config.color : "transparent",
                color: activeGroup === key ? "var(--white)" : config.color,
                border: "1px solid " + config.color,
                fontSize: "10px",
                padding: "2px 8px",
              }}
            >
              {config.label}
            </button>
          ))}
        </div>
      )}

      <style>{`
        /* Cards separadas: cabecera navy + tabla */
        .table-wrapper {
          border-radius: 20px;
          border: 1px solid var(--color-border, #E5E7EB) !important;
          overflow: hidden;
        }
        .premium-table {
          border-collapse: separate !important;
          border-spacing: 0 !important;
          border: none !important;
          border-radius: 0 !important;
          overflow: visible !important;
          table-layout: fixed !important;
        }
        .premium-table thead th {
          color: white !important;
          padding: 12px 16px !important;
          font-weight: 700;
          font-size: 11px;
          letter-spacing: 0.05em;
          border: none !important;
        }
        .premium-table tbody tr:first-child td {
          border-top: none !important;
        }
        .premium-table tbody td {
          padding: 5px 8px !important;
          border-bottom: 1px solid #F3F4F6 !important;
          font-size: 10px !important;
        }
        .block-banner {
          background: var(--color-bg-subtle) !important;
        }
        .block-banner td {
          padding: 8px 16px !important;
          border-bottom: 1px solid var(--color-border, #E5E7EB) !important;
        }
        .drag-handle--tooltip {
          position: relative;
          cursor: grab;
          padding: 4px;
          margin: -4px;
          border-radius: 4px;
        }
        .drag-handle--tooltip:hover {
          background: var(--color-bg-subtle);
        }
        .drag-handle--tooltip::after {
          content: attr(title);
          position: absolute;
          bottom: calc(100% + 6px);
          left: 50%;
          transform: translateX(-50%);
          background: var(--color-navy, #0D2640);
          color: white;
          padding: 4px 8px;
          border-radius: 6px;
          font-size: 10px;
          font-weight: 600;
          white-space: nowrap;
          opacity: 0;
          pointer-events: none;
          transition: opacity 0.15s ease;
        }
        .drag-handle--tooltip:hover::after {
          opacity: 1;
        }
      `}</style>

      <div className="overflow-x-auto">
        <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
          {/* Card cabecera */}
          <div
            className="table-wrapper"
            style={{
              borderRadius: "20px",
              overflow: "hidden",
              background: "transparent",
            }}
          >
            <table
              className={`w-full min-w-[700px] premium-table ${headerClassName || ""}`}
              style={{
                border: "none !important",
                borderRadius: 0,
                overflow: "visible",
              }}
            >
              <thead>
                <tr>
                  <th
                    style={{
                      width: "28px",
                      minWidth: "28px",
                      ...(headerStyle
                        ? { padding: "6px 8px", ...headerStyle }
                        : {
                            padding: "12px 16px",
                            background: "var(--color-navy, #0D2640)",
                          }),
                    }}
                  ></th>
                    {columns.map((col) => (
                      <th
                        key={col.key}
                        className={`${headerClassName ? `${headerClassName}-cell` : ""} premium-table-head-cell`}
                        style={{
                          minWidth: col.minWidth || "auto",
                          maxWidth: col.maxWidth || "none",
                          width: col.width || "auto",
                           ...(headerStyle
                             ? { padding: "6px 8px", ...headerStyle, color: "inherit" }
                             : {
                                 padding: "12px 16px",
                                 background: "var(--color-navy, #0D2640)",
                                 fontWeight: 700,
                                 fontSize: "11px",
                                 letterSpacing: "0.05em",
                               }),
                          textAlign: col.align || "left",
                        }}
                      >
                        {col.label}
                      </th>
                    ))}
                  <th
                    style={{
                      width: "24px",
                      minWidth: "24px",
                      ...(headerStyle
                        ? { padding: "6px 8px", ...headerStyle }
                        : {
                            padding: "12px 16px",
                            background: "var(--color-navy, #0D2640)",
                          }),
                    }}
                  ></th>
                </tr>
              </thead>
            </table>
          </div>

           {/* Card tabla */}
          <div
            className="table-wrapper"
            style={{
              borderRadius: "20px",
              border: "1px solid #E8E8E8",
              overflow: "hidden",
            }}
          >
            <table
              className="w-full min-w-[700px] premium-table"
              style={{
                border: "none !important",
                borderRadius: 0,
                overflow: "visible",
              }}
            >
              <tbody>
                {groupRows.map(({ key: groupKey, rows: groupRowsData }) => {
                  const showGroupHeader =
                    groupConfig &&
                    groupKey &&
                    groupConfig[groupKey]?.className === "menu-group-header";
                  const isEmpty = groupRowsData.length === 0;
                  return (
                    <React.Fragment key={groupKey}>
                      {isEmpty && (
                        <tr>
                          <td
                            colSpan={columns.length + 2}
                            className="premium-table-cell text-center typo-muted-sm"
                          >
                            {emptyText || "Sin datos"}
                          </td>
                        </tr>
                      )}
                      {showGroupHeader && (
                        <tr>
                          <td
                            colSpan={columns.length + 2}
                            className="premium-table-cell"
                            style={{
                              padding: "0px",
                              borderBottom:
                                "1px solid " +
                                (groupConfig[groupKey]?.color ||
                                  "var(--color-bg-subtle)") +
                                "33",
                            }}
                          >
                            <div
                              className="menu-group-header"
                              style={{
                                background: "transparent",
                                padding: "0px",
                                fontSize: "9px",
                                fontWeight: 800,
                                letterSpacing: "0.1em",
                                textTransform: "uppercase",
                                color: "#0D2640",
                                marginBottom: "4px",
                                marginTop: "6px",
                              }}
                            >
                              <div
                                style={{
                                  flex: 1,
                                  display: "flex",
                                  alignItems: "center",
                                  gap: "8px",
                                }}
                              >
                                <span style={{ fontSize: "9px", fontWeight: 800, letterSpacing: "0.1em", textTransform: "uppercase", color: "#0D2640" }}>
                                  {groupConfig[groupKey]?.label || groupKey}
                                </span>
                              </div>
                              {groupAddRow && groupAddRow[groupKey] && (
                                <button
                                  onClick={groupAddRow[groupKey]}
                                  className="menu-group-add-btn menu-group-add-btn--primary"
                                >
                                  {groupAddRowLabel}
                                </button>
                              )}
                              {groupRemoveRow && groupRemoveRow[groupKey] && (
                                <button
                                  onClick={groupRemoveRow[groupKey]}
                                  className="premium-btn-delete"
                                  type="button"
                                >
                                  <IconX size={10} />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      )}
                      {groupRowsData.map((row, idx) => (
                        <React.Fragment
                          key={getRowId ? getRowId(row, idx) : String(idx)}
                        >
                          <tr
                            className={
                              "premium-table-row" +
                              (row.isFirstInBlock
                                ? " premium-table-row--first"
                                : "") +
                              (row.isLastInBlock
                                ? " premium-table-row--last"
                                : "") +
                              (row.isOption ? " premium-table-row--option" : "")
                            }
                            onDragStart={handleDragStart(
                              getRowId ? getRowId(row, idx) : String(idx),
                            )}
                            onDragEnd={handleDragEnd}
                            onDragOver={handleDragOver(
                              getRowId ? getRowId(row, idx) : String(idx),
                            )}
                            onDrop={handleDrop(
                              getRowId ? getRowId(row, idx) : String(idx),
                            )}
                            onDragEnter={handleDragEnter}
                            onDragLeave={handleDragLeave}
                            style={
                              dropUid ===
                              (getRowId ? getRowId(row, idx) : String(idx))
                                ? {
                                    background: "var(--color-primary-50)",
                                    outline:
                                      "2px dashed var(--color-primary-300)",
                                  }
                                : {}
                            }
                          >
                            <td
                              className="premium-table-cell-base premium-table-cell--center"
                              style={{ width: "28px" }}
                            >
                              <span
                                draggable
                                data-drag-handle
                                className="drag-handle drag-handle--tooltip"
                                title="Arrastrar para reordenar"
                              >
                                ⋮⋮
                              </span>
                            </td>
                            {columns.map((col) => (
                              <td
                                key={col.key}
                                className={
                                  "premium-table-cell-base " +
                                  (col.className || "")
                                }
                                style={{
                                  minWidth: col.minWidth || "auto",
                                  maxWidth: col.maxWidth || "none",
                                  width: col.width || "auto",
                                  textAlign: col.align || "left",
                                  ...(col.style || {}),
                                }}
                              >
                                {col.render
                                  ? col.render(
                                      row[col.key],
                                      row,
                                      (field, value) =>
                                        onUpdateRow &&
                                        onUpdateRow(
                                          getRowId
                                            ? getRowId(row, idx)
                                            : String(idx),
                                          field,
                                          value,
                                        ),
                                      getRowId
                                        ? getRowId(row, idx)
                                        : String(idx),
                                      idx,
                                    )
                                  : (row[col.key] ?? "")}
                              </td>
                            ))}
                            <td
                              className="premium-table-cell-base premium-table-cell--center"
                              style={{ width: "24px" }}
                            >
                              <button
                                onClick={() =>
                                  onRemoveRow &&
                                  onRemoveRow(
                                    getRowId ? getRowId(row, idx) : String(idx),
                                  )
                                }
                                className="premium-btn-delete"
                                type="button"
                              >
                                <IconX />
                              </button>
                            </td>
                          </tr>
                        </React.Fragment>
                      ))}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {onAddRow && !groupAddRow && (
        <button
          onClick={onAddRow}
          className="menu-group-add-btn menu-group-add-btn--primary"
        >
          {addButtonLabel || "+ AGREGAR FILA"}
        </button>
      )}
    </div>
  );
}
